#!/usr/bin/env python3
"""
End-to-End Healthcare AI Fairness Audit Pipeline.

Usage:
    python scripts/run_full_audit.py
    python scripts/run_full_audit.py --model random_forest --bias 0.8 --samples 8000

Steps:
  1. Generate synthetic clinical dataset with injected bias
  2. Preprocess features and create train/test splits
  3. Train baseline model (Logistic Regression)
  4. Compute pre-mitigation fairness metrics
  5. Generate SHAP explanations
  6. Apply bias mitigation (Reweighing + Threshold Calibration)
  7. Retrain with mitigated data and re-evaluate fairness
  8. Compare before vs after
  9. Save plots and generate structured report
"""

import sys
import os
import argparse
import logging
from pathlib import Path

# Make src importable
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))

import numpy as np
import pandas as pd

from data.generator import ClinicalDataGenerator, load_or_generate
from data.preprocessor import ClinicalPreprocessor
from models.trainer import ClinicalModelTrainer
from fairness.metrics import FairnessAuditor, MultiGroupFairnessAuditor, format_fairness_report
from fairness.mitigation import CustomReweighing, GroupThresholdCalibrator, compare_mitigation_results
from visualization.plots import (
    plot_fairness_metrics, plot_group_comparison, plot_mitigation_comparison,
    plot_readmission_disparity, plot_shap_importance, plot_roc_by_group,
    plot_dashboard_summary,
)
from utils.reporting import setup_logging, save_json, generate_audit_report

try:
    from explainability.shap_explainer import SHAPExplainer, BiasAttributionAnalyzer
    SHAP_AVAILABLE = True
except Exception:
    SHAP_AVAILABLE = False

logger = logging.getLogger(__name__)


def parse_args():
    parser = argparse.ArgumentParser(description="Healthcare AI Fairness Audit")
    parser.add_argument("--model", default="logistic",
                        choices=["logistic", "random_forest", "gradient_boosting", "xgboost"],
                        help="Model architecture to train")
    parser.add_argument("--samples", type=int, default=5000,
                        help="Number of synthetic patient records")
    parser.add_argument("--bias", type=float, default=0.7,
                        help="Bias injection strength [0.0, 1.0]")
    parser.add_argument("--sensitive", default="race_binary",
                        choices=["race_binary", "zip_binary"],
                        help="Sensitive attribute for fairness audit")
    parser.add_argument("--output-dir", default="reports",
                        help="Output directory for plots and report")
    parser.add_argument("--no-shap", action="store_true",
                        help="Skip SHAP computation (faster)")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    return parser.parse_args()


def main():
    args = parse_args()
    setup_logging("INFO", log_file="reports/audit.log")

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    plots_dir = output_dir / "plots"
    plots_dir.mkdir(exist_ok=True)

    logger.info("=" * 60)
    logger.info("  HEALTHCARE AI FAIRNESS AUDIT PIPELINE")
    logger.info("=" * 60)

    # ── STEP 1: Generate Data ────────────────────────────────────────────────
    logger.info("\n[STEP 1] Generating synthetic clinical dataset...")
    gen = ClinicalDataGenerator(
        n_samples=args.samples,
        bias_strength=args.bias,
        random_state=args.seed,
    )
    df_raw = gen.generate(save_path="data/clinical_dataset.csv")
    summary = gen.get_dataset_summary(df_raw)
    logger.info(f"  Readmission rates by race: {summary['by_race']}")
    logger.info(f"  Readmission rates by ZIP: {summary['by_zip_group']}")

    # ── STEP 2: Preprocess ───────────────────────────────────────────────────
    logger.info("\n[STEP 2] Preprocessing features...")
    preprocessor = ClinicalPreprocessor(test_size=0.2, random_state=args.seed)
    X_train, X_test, y_train, y_test, df_train, df_test = preprocessor.preprocess(df_raw)
    feature_names = preprocessor.get_feature_names()
    logger.info(f"  Feature count: {len(feature_names)}")

    # ── STEP 3: Train Baseline Model ─────────────────────────────────────────
    logger.info(f"\n[STEP 3] Training baseline {args.model} model...")
    trainer = ClinicalModelTrainer(model_name=args.model, model_dir="models/")
    trainer.train(X_train, y_train)
    baseline_metrics = trainer.evaluate(X_test, y_test)
    trainer.save()

    logger.info(f"  Baseline AUC: {baseline_metrics['roc_auc']:.4f}")
    logger.info(f"  Baseline F1:  {baseline_metrics['f1']:.4f}")

    # ── STEP 4: Pre-Mitigation Fairness Metrics ───────────────────────────────
    logger.info(f"\n[STEP 4] Computing pre-mitigation fairness metrics...")
    y_pred_test = trainer.predict(X_test)
    y_proba_test = trainer.predict_proba(X_test)

    auditor = FairnessAuditor(sensitive_col=args.sensitive, privileged_value=1)
    fairness_before = auditor.compute_all(df_test, y_test, y_pred_test, y_proba_test)
    print(format_fairness_report(fairness_before, model_name=f"Baseline {args.model}"))

    # Multi-group race analysis
    multi_auditor = MultiGroupFairnessAuditor(sensitive_col="race", label_col="readmitted")
    multi_group_df = multi_auditor.compute(df_test, y_test, y_pred_test)
    logger.info(f"\n  Multi-group breakdown:\n{multi_group_df.to_string()}")

    # ── STEP 5: SHAP Explanations ─────────────────────────────────────────────
    bias_narrative = ""
    shap_importance = None
    if SHAP_AVAILABLE and not args.no_shap:
        logger.info("\n[STEP 5] Computing SHAP explanations...")
        try:
            explainer = SHAPExplainer(
                model=trainer.model,
                feature_names=feature_names,
                model_type="auto",
            )
            explainer.fit(X_train, n_background=100)
            shap_values = explainer.explain(X_test, n_samples=500)
            shap_importance = explainer.get_global_importance()

            logger.info(f"\n  Top 5 features by SHAP:")
            for _, row in shap_importance.head(5).iterrows():
                logger.info(f"    {row['feature']:<30} {row['mean_abs_shap']:.5f}")

            # Bias attribution
            bias_analyzer = BiasAttributionAnalyzer(explainer)
            bias_narrative = bias_analyzer.generate_bias_narrative(
                df_test.reset_index(drop=True).head(len(shap_values)),
                sensitive_col=args.sensitive,
            )
            logger.info(bias_narrative)

            # SHAP plot
            plot_shap_importance(
                shap_importance,
                save_path=str(plots_dir / "shap_importance.png"),
            )
        except Exception as e:
            logger.warning(f"  SHAP computation encountered an error: {e}")
    else:
        logger.info("\n[STEP 5] Skipping SHAP (--no-shap flag or SHAP unavailable).")

    # ── STEP 6: Apply Bias Mitigation ─────────────────────────────────────────
    logger.info("\n[STEP 6] Applying bias mitigation...")

    # 6a. Reweighing (pre-processing)
    logger.info("  6a. Reweighing (pre-processing)...")
    reweigher = CustomReweighing(
        sensitive_col=args.sensitive, label_col="readmitted", privileged_value=1
    )
    reweigher.fit(df_train)
    sample_weights = reweigher.get_weights()

    trainer_rw = ClinicalModelTrainer(model_name=args.model, model_dir="models/")
    trainer_rw.train(X_train, y_train)
    # Retrain with weights
    trainer_rw.model.fit(X_train, y_train, sample_weight=sample_weights)
    trainer_rw._trained = True
    rw_metrics = trainer_rw.evaluate(X_test, y_test)
    y_pred_rw = trainer_rw.predict(X_test)
    y_proba_rw = trainer_rw.predict_proba(X_test)
    fairness_rw = auditor.compute_all(df_test, y_test, y_pred_rw, y_proba_rw)
    logger.info(f"  Reweighing AUC: {rw_metrics['roc_auc']:.4f}")

    # 6b. Group Threshold Calibration (post-processing)
    logger.info("  6b. Group threshold calibration (post-processing)...")
    calibrator = GroupThresholdCalibrator(
        sensitive_col=args.sensitive, privileged_value=1, label_col="readmitted"
    )
    calibrator.fit(df_test, y_test, y_proba_test)
    y_pred_calibrated = calibrator.predict(df_test, y_proba_test)
    fairness_calibrated = auditor.compute_all(df_test, y_test, y_pred_calibrated, y_proba_test)
    logger.info(f"  Calibrated thresholds: {calibrator.get_thresholds()}")

    # Choose best mitigation result (lowest |EOD|)
    eod_rw = abs(fairness_rw.get("equal_opportunity_difference", 999))
    eod_cal = abs(fairness_calibrated.get("equal_opportunity_difference", 999))
    if eod_cal < eod_rw:
        fairness_after = fairness_calibrated
        best_method = "Group Threshold Calibration"
        y_pred_final = y_pred_calibrated
    else:
        fairness_after = fairness_rw
        best_method = "Reweighing"
        y_pred_final = y_pred_rw

    logger.info(f"\n  Best mitigation: {best_method}")
    print(format_fairness_report(fairness_after, model_name=f"Mitigated ({best_method})"))

    # ── STEP 7: Compare Before vs After ──────────────────────────────────────
    logger.info("\n[STEP 7] Comparing fairness before vs after mitigation...")
    comparison = compare_mitigation_results(fairness_before, fairness_after, best_method)
    logger.info(f"\n{comparison.to_string()}")

    # ── STEP 8: Generate Visualizations ──────────────────────────────────────
    logger.info("\n[STEP 8] Generating visualizations...")

    plot_readmission_disparity(
        df_raw, group_col="race",
        save_path=str(plots_dir / "readmission_by_race.png"),
    )
    plot_readmission_disparity(
        df_raw, group_col="zip_group",
        save_path=str(plots_dir / "readmission_by_zip.png"),
    )
    plot_fairness_metrics(
        fairness_before,
        title="Fairness Metrics — Before Mitigation",
        save_path=str(plots_dir / "fairness_before.png"),
    )
    plot_fairness_metrics(
        fairness_after,
        title=f"Fairness Metrics — After {best_method}",
        save_path=str(plots_dir / "fairness_after.png"),
    )
    plot_group_comparison(
        fairness_before.get("group_breakdown", {}),
        save_path=str(plots_dir / "group_comparison.png"),
    )
    plot_mitigation_comparison(
        comparison,
        title=f"Fairness Before vs After — {best_method}",
        save_path=str(plots_dir / "mitigation_comparison.png"),
    )
    plot_roc_by_group(
        df_test, y_test, y_proba_test,
        sensitive_col=args.sensitive,
        save_path=str(plots_dir / "roc_by_group.png"),
    )
    plot_dashboard_summary(
        metrics_before=fairness_before,
        metrics_after=fairness_after,
        group_breakdown=fairness_before.get("group_breakdown", {}),
        model_name=args.model,
        save_path=str(plots_dir / "dashboard_summary.png"),
    )
    logger.info(f"  All plots saved to {plots_dir}/")

    # ── STEP 9: Save Results & Report ────────────────────────────────────────
    logger.info("\n[STEP 9] Saving results and generating report...")

    results = {
        "config": vars(args),
        "dataset_summary": summary,
        "model_metrics": baseline_metrics,
        "fairness_before": {k: v for k, v in fairness_before.items()
                            if not isinstance(v, dict)},
        "fairness_after": {k: v for k, v in fairness_after.items()
                           if not isinstance(v, dict)},
        "best_mitigation": best_method,
        "mitigation_comparison": comparison.reset_index().to_dict(orient="records"),
    }
    save_json(results, str(output_dir / "audit_results.json"))

    report = generate_audit_report(
        model_metrics=baseline_metrics,
        fairness_before=fairness_before,
        fairness_after=fairness_after,
        mitigation_method=best_method,
        output_path=str(output_dir / "fairness_audit_report.md"),
    )

    logger.info("\n" + "=" * 60)
    logger.info("  AUDIT COMPLETE")
    logger.info(f"  Report:  {output_dir}/fairness_audit_report.md")
    logger.info(f"  Results: {output_dir}/audit_results.json")
    logger.info(f"  Plots:   {plots_dir}/")
    logger.info("=" * 60)

    return results


if __name__ == "__main__":
    main()
