"""
Healthcare AI Fairness Audit — Streamlit Dashboard.

Interactive web application for bias auditing of clinical prediction models.
Supports dataset upload, model training, fairness metric visualization,
SHAP explanations, and mitigation comparison.

Run with:
    streamlit run dashboards/app.py
"""

import sys
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))

import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import io

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Healthcare AI Fairness Audit",
    page_icon="⚕️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .main-header {
        font-size: 2.4rem;
        font-weight: 800;
        color: #2C3E7A;
        margin-bottom: 0.25rem;
    }
    .sub-header {
        font-size: 1.1rem;
        color: #6C757D;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: #F8F9FA;
        border-radius: 10px;
        padding: 1.2rem;
        border-left: 4px solid #2C3E7A;
        margin-bottom: 1rem;
    }
    .fair-badge {
        background: #27AE60;
        color: white;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 0.8rem;
        font-weight: bold;
    }
    .bias-badge {
        background: #E84040;
        color: white;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 0.8rem;
        font-weight: bold;
    }
</style>
""", unsafe_allow_html=True)


# ── Lazy imports ─────────────────────────────────────────────────────────────
@st.cache_resource
def _load_modules():
    from data.generator import ClinicalDataGenerator
    from data.preprocessor import ClinicalPreprocessor
    from models.trainer import ClinicalModelTrainer
    from fairness.metrics import FairnessAuditor, MultiGroupFairnessAuditor
    from fairness.mitigation import CustomReweighing, GroupThresholdCalibrator, compare_mitigation_results
    from visualization.plots import (
        plot_fairness_metrics, plot_group_comparison,
        plot_mitigation_comparison, plot_readmission_disparity,
        plot_roc_by_group, plot_calibration_by_group,
    )
    return dict(
        ClinicalDataGenerator=ClinicalDataGenerator,
        ClinicalPreprocessor=ClinicalPreprocessor,
        ClinicalModelTrainer=ClinicalModelTrainer,
        FairnessAuditor=FairnessAuditor,
        MultiGroupFairnessAuditor=MultiGroupFairnessAuditor,
        CustomReweighing=CustomReweighing,
        GroupThresholdCalibrator=GroupThresholdCalibrator,
        compare_mitigation_results=compare_mitigation_results,
        plot_fairness_metrics=plot_fairness_metrics,
        plot_group_comparison=plot_group_comparison,
        plot_mitigation_comparison=plot_mitigation_comparison,
        plot_readmission_disparity=plot_readmission_disparity,
        plot_roc_by_group=plot_roc_by_group,
        plot_calibration_by_group=plot_calibration_by_group,
    )


def fig_to_image(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=130, bbox_inches="tight")
    buf.seek(0)
    plt.close(fig)
    return buf


# ── Sidebar ───────────────────────────────────────────────────────────────────
def sidebar_controls():
    st.sidebar.image("https://img.shields.io/badge/AI-Fairness%20Audit-2C3E7A?style=for-the-badge")
    st.sidebar.markdown("---")

    st.sidebar.header("⚙️ Dataset Settings")
    n_samples = st.sidebar.slider("Sample size", 1000, 10000, 3000, 500)
    bias_strength = st.sidebar.slider("Bias strength", 0.0, 1.0, 0.7, 0.05,
                                       help="Controls how much demographic bias is injected")
    random_seed = st.sidebar.number_input("Random seed", value=42, step=1)
    uploaded = st.sidebar.file_uploader(
        "Or upload your own CSV", type=["csv"],
        help="Must contain 'readmitted' and 'race' / 'zip_group' columns"
    )

    st.sidebar.markdown("---")
    st.sidebar.header("🤖 Model Settings")
    model_name = st.sidebar.selectbox(
        "Model", ["logistic", "random_forest", "gradient_boosting"], index=0
    )
    sensitive_attr = st.sidebar.selectbox(
        "Sensitive attribute", ["race_binary", "zip_binary"], index=0
    )

    st.sidebar.markdown("---")
    st.sidebar.header("🛡️ Mitigation Settings")
    mitigation = st.sidebar.multiselect(
        "Apply mitigation", ["Reweighing", "Group Threshold Calibration"],
        default=["Reweighing", "Group Threshold Calibration"]
    )

    return dict(
        n_samples=n_samples, bias_strength=bias_strength, seed=int(random_seed),
        uploaded=uploaded, model_name=model_name, sensitive=sensitive_attr,
        mitigation=mitigation,
    )


# ── Main App ──────────────────────────────────────────────────────────────────
def main():
    st.markdown('<div class="main-header">⚕️ Healthcare AI Fairness Audit</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">Detect, Explain, and Mitigate Algorithmic Bias in Clinical Decision Models</div>', unsafe_allow_html=True)

    config = sidebar_controls()

    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📊 Dataset", "🤖 Model", "⚖️ Fairness Metrics", "🔍 Explainability", "🛡️ Mitigation"
    ])

    # ─ Lazy load ─
    try:
        M = _load_modules()
    except Exception as e:
        st.error(f"Failed to load modules. Ensure all dependencies are installed.\n\n`{e}`")
        st.stop()

    # ── TAB 1: Dataset ──────────────────────────────────────────────────────
    with tab1:
        st.header("Dataset Overview")

        if config["uploaded"] is not None:
            df_raw = pd.read_csv(config["uploaded"])
            st.success(f"✅ Loaded uploaded dataset: {len(df_raw):,} rows")
        else:
            with st.spinner("Generating synthetic clinical dataset..."):
                gen = M["ClinicalDataGenerator"](
                    n_samples=config["n_samples"],
                    bias_strength=config["bias_strength"],
                    random_state=config["seed"],
                )
                df_raw = gen.generate()
            st.success(f"✅ Generated {len(df_raw):,} synthetic patient records (bias={config['bias_strength']})")

        st.session_state["df_raw"] = df_raw

        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Total Patients", f"{len(df_raw):,}")
        col2.metric("Readmission Rate", f"{df_raw['readmitted'].mean():.1%}")
        col3.metric("Unique Races", str(df_raw['race'].nunique()))
        col4.metric("Features", str(df_raw.shape[1]))

        col_a, col_b = st.columns(2)
        with col_a:
            st.subheader("Readmission Rate by Race")
            fig = M["plot_readmission_disparity"](df_raw, group_col="race")
            st.image(fig_to_image(fig))
        with col_b:
            st.subheader("Readmission Rate by ZIP Group")
            fig = M["plot_readmission_disparity"](df_raw, group_col="zip_group")
            st.image(fig_to_image(fig))

        st.subheader("Dataset Preview")
        st.dataframe(df_raw.head(20), use_container_width=True)

        st.subheader("Summary Statistics")
        st.dataframe(df_raw.describe().round(3), use_container_width=True)

    # ── TAB 2: Model ────────────────────────────────────────────────────────
    with tab2:
        st.header("Model Training & Evaluation")

        if "df_raw" not in st.session_state:
            st.warning("⚠️ Please load a dataset in the Dataset tab first.")
            return

        if st.button("🚀 Train Model", type="primary", key="train_btn"):
            df_raw = st.session_state["df_raw"]

            with st.spinner("Preprocessing data..."):
                preprocessor = M["ClinicalPreprocessor"](test_size=0.2, random_state=config["seed"])
                X_train, X_test, y_train, y_test, df_train, df_test = preprocessor.preprocess(df_raw)
                feature_names = preprocessor.get_feature_names()

            with st.spinner(f"Training {config['model_name']} model..."):
                trainer = M["ClinicalModelTrainer"](model_name=config["model_name"], model_dir="models/")
                trainer.train(X_train, y_train)
                metrics = trainer.evaluate(X_test, y_test)

            st.session_state.update(dict(
                preprocessor=preprocessor, trainer=trainer, metrics=metrics,
                X_train=X_train, X_test=X_test, y_train=y_train, y_test=y_test,
                df_train=df_train, df_test=df_test, feature_names=feature_names,
            ))
            st.success("✅ Model trained successfully!")

        if "metrics" in st.session_state:
            m = st.session_state["metrics"]
            c1, c2, c3, c4, c5 = st.columns(5)
            c1.metric("ROC-AUC", f"{m['roc_auc']:.4f}")
            c2.metric("F1 Score", f"{m['f1']:.4f}")
            c3.metric("Precision", f"{m['precision']:.4f}")
            c4.metric("Recall", f"{m['recall']:.4f}")
            c5.metric("Accuracy", f"{m['accuracy']:.4f}")

            st.subheader("Feature Importances")
            fi = st.session_state["trainer"].get_feature_importances(
                st.session_state["feature_names"]
            )
            if fi is not None:
                st.dataframe(fi.head(15), use_container_width=True)

    # ── TAB 3: Fairness Metrics ──────────────────────────────────────────────
    with tab3:
        st.header("Fairness Analysis")

        if "trainer" not in st.session_state:
            st.warning("⚠️ Please train a model in the Model tab first.")
            return

        if st.button("⚖️ Run Fairness Audit", type="primary", key="fairness_btn"):
            trainer = st.session_state["trainer"]
            X_test = st.session_state["X_test"]
            y_test = st.session_state["y_test"]
            df_test = st.session_state["df_test"]

            y_pred = trainer.predict(X_test)
            y_proba = trainer.predict_proba(X_test)

            auditor = M["FairnessAuditor"](
                sensitive_col=config["sensitive"], privileged_value=1
            )
            fairness = auditor.compute_all(df_test, y_test, y_pred, y_proba)
            st.session_state.update(dict(
                fairness_before=fairness, y_pred=y_pred, y_proba=y_proba
            ))
            st.success("✅ Fairness audit complete!")

        if "fairness_before" in st.session_state:
            fb = st.session_state["fairness_before"]
            flags = fb.get("fairness_flags", {})

            st.subheader("Fairness Metric Summary")
            metric_names = {
                "disparate_impact": ("Disparate Impact", 0.8, 1.25),
                "statistical_parity_difference": ("Statistical Parity Diff.", -0.1, 0.1),
                "equal_opportunity_difference": ("Equal Opportunity Diff.", -0.1, 0.1),
                "average_odds_difference": ("Average Odds Diff.", -0.1, 0.1),
                "predictive_parity_difference": ("Predictive Parity Diff.", -0.1, 0.1),
            }

            cols = st.columns(len(metric_names))
            for col, (key, (label, lo, hi)) in zip(cols, metric_names.items()):
                val = fb.get(key, float("nan"))
                is_fair = flags.get(key, False)
                badge = "✅ Fair" if is_fair else "❌ Biased"
                col.metric(label, f"{val:.4f}", delta=badge,
                           delta_color="normal" if is_fair else "inverse")

            col1, col2 = st.columns(2)
            with col1:
                st.subheader("Fairness Metrics Chart")
                fig = M["plot_fairness_metrics"](fb)
                st.image(fig_to_image(fig))
            with col2:
                st.subheader("Group Performance Comparison")
                fig = M["plot_group_comparison"](fb.get("group_breakdown", {}))
                st.image(fig_to_image(fig))

            st.subheader("ROC Curve by Group")
            fig = M["plot_roc_by_group"](
                st.session_state["df_test"],
                st.session_state["y_test"],
                st.session_state["y_proba"],
                sensitive_col=config["sensitive"],
            )
            st.image(fig_to_image(fig))

            st.subheader("Multi-Group Breakdown by Race")
            multi = M["MultiGroupFairnessAuditor"](sensitive_col="race")
            mg_df = multi.compute(
                st.session_state["df_test"],
                st.session_state["y_test"],
                st.session_state["y_pred"],
            )
            st.dataframe(mg_df.style.background_gradient(cmap="RdYlGn", axis=None),
                         use_container_width=True)

    # ── TAB 4: Explainability ─────────────────────────────────────────────────
    with tab4:
        st.header("Model Explainability (SHAP)")

        try:
            import shap
            SHAP_OK = True
        except ImportError:
            SHAP_OK = False
            st.error("SHAP is not installed. Run: `pip install shap`")

        if SHAP_OK and "trainer" in st.session_state:
            n_explain = st.slider("Samples to explain", 100, 1000, 300, 50)
            if st.button("🔍 Compute SHAP Values", key="shap_btn"):
                from explainability.shap_explainer import SHAPExplainer, BiasAttributionAnalyzer

                X_train = st.session_state["X_train"]
                X_test = st.session_state["X_test"]
                feature_names = st.session_state["feature_names"]
                trainer = st.session_state["trainer"]

                with st.spinner("Computing SHAP values..."):
                    explainer = SHAPExplainer(trainer.model, feature_names, model_type="auto")
                    explainer.fit(X_train, n_background=100)
                    explainer.explain(X_test, n_samples=n_explain)
                    shap_imp = explainer.get_global_importance()

                st.session_state["shap_explainer"] = explainer
                st.session_state["shap_importance"] = shap_imp
                st.success("✅ SHAP values computed!")

            if "shap_importance" in st.session_state:
                from visualization.plots import plot_shap_importance
                st.subheader("Global Feature Importance")
                fig = plot_shap_importance(st.session_state["shap_importance"])
                st.image(fig_to_image(fig))

                st.subheader("Top Features by Impact")
                st.dataframe(
                    st.session_state["shap_importance"].head(15),
                    use_container_width=True
                )
        elif "trainer" not in st.session_state:
            st.warning("⚠️ Please train a model first.")

    # ── TAB 5: Mitigation ────────────────────────────────────────────────────
    with tab5:
        st.header("Bias Mitigation")

        if "fairness_before" not in st.session_state:
            st.warning("⚠️ Please run a fairness audit first.")
            return

        if st.button("🛡️ Apply Mitigation", type="primary", key="mitigate_btn"):
            df_train = st.session_state["df_train"]
            df_test = st.session_state["df_test"]
            X_train = st.session_state["X_train"]
            X_test = st.session_state["X_test"]
            y_train = st.session_state["y_train"]
            y_test = st.session_state["y_test"]
            y_proba = st.session_state["y_proba"]
            trainer = st.session_state["trainer"]
            fairness_before = st.session_state["fairness_before"]

            auditor = M["FairnessAuditor"](sensitive_col=config["sensitive"], privileged_value=1)
            fairness_after = fairness_before  # Default

            if "Reweighing" in config["mitigation"]:
                with st.spinner("Applying Reweighing..."):
                    rw = M["CustomReweighing"](
                        sensitive_col=config["sensitive"], label_col="readmitted"
                    )
                    rw.fit(df_train)
                    weights = rw.get_weights()
                    new_trainer = M["ClinicalModelTrainer"](
                        model_name=config["model_name"], model_dir="models/"
                    )
                    new_trainer.train(X_train, y_train)
                    new_trainer.model.fit(X_train, y_train, sample_weight=weights)
                    new_trainer._trained = True
                    y_pred_rw = new_trainer.predict(X_test)
                    y_proba_rw = new_trainer.predict_proba(X_test)
                    fairness_after = auditor.compute_all(df_test, y_test, y_pred_rw, y_proba_rw)

            if "Group Threshold Calibration" in config["mitigation"]:
                with st.spinner("Applying Group Threshold Calibration..."):
                    cal = M["GroupThresholdCalibrator"](
                        sensitive_col=config["sensitive"], privileged_value=1
                    )
                    cal.fit(df_test, y_test, y_proba)
                    y_pred_cal = cal.predict(df_test, y_proba)
                    fairness_cal = auditor.compute_all(df_test, y_test, y_pred_cal, y_proba)

                    # Pick best
                    if abs(fairness_cal.get("equal_opportunity_difference", 999)) < \
                       abs(fairness_after.get("equal_opportunity_difference", 999)):
                        fairness_after = fairness_cal

            st.session_state["fairness_after"] = fairness_after
            comparison = M["compare_mitigation_results"](fairness_before, fairness_after)
            st.session_state["comparison"] = comparison
            st.success("✅ Mitigation applied!")

        if "fairness_after" in st.session_state:
            fb = st.session_state["fairness_before"]
            fa = st.session_state["fairness_after"]
            comparison = st.session_state["comparison"]

            st.subheader("Fairness: Before vs After Mitigation")
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("**Before Mitigation**")
                fig = M["plot_fairness_metrics"](fb, title="Before")
                st.image(fig_to_image(fig))
            with col2:
                st.markdown("**After Mitigation**")
                fig = M["plot_fairness_metrics"](fa, title="After")
                st.image(fig_to_image(fig))

            st.subheader("Metric Changes")
            fig = M["plot_mitigation_comparison"](comparison)
            st.image(fig_to_image(fig))

            st.subheader("Detailed Comparison Table")
            styled = comparison.reset_index().style.apply(
                lambda row: [
                    "background-color: #d4edda" if row.get("improved", False) else
                    "background-color: #f8d7da"
                ] * len(row),
                axis=1,
            )
            st.dataframe(comparison.reset_index(), use_container_width=True)

            # Download report
            from utils.reporting import generate_audit_report
            report_md = generate_audit_report(
                model_metrics=st.session_state.get("metrics", {}),
                fairness_before=fb,
                fairness_after=fa,
                mitigation_method=", ".join(config["mitigation"]) or "None",
                output_path="/tmp/audit_report.md",
            )
            st.download_button(
                label="📥 Download Audit Report (Markdown)",
                data=report_md,
                file_name="fairness_audit_report.md",
                mime="text/markdown",
            )


if __name__ == "__main__":
    main()
