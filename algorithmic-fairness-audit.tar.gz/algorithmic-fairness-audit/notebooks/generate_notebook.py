"""
Generate the Jupyter notebook for the fairness audit demo.
Run: python notebooks/generate_notebook.py
"""
import json
from pathlib import Path

nb = {
    "nbformat": 4,
    "nbformat_minor": 5,
    "metadata": {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {"name": "python", "version": "3.10.0"},
    },
    "cells": []
}

def md(source): return {"cell_type": "markdown", "metadata": {}, "source": source, "id": "md_" + str(hash(source))[:8]}
def code(source): return {"cell_type": "code", "metadata": {}, "source": source, "outputs": [], "execution_count": None, "id": "cd_" + str(hash(source))[:8]}

nb["cells"] = [
    md("""# ⚕️ Healthcare AI Fairness Audit — Demo Notebook

> **A step-by-step walkthrough of bias detection, explanation, and mitigation in clinical prediction models.**

## Agenda
1. Generate synthetic clinical dataset with injected bias
2. Preprocess and explore demographic disparities
3. Train a clinical readmission prediction model
4. Compute fairness metrics (Disparate Impact, EOD, SPD, AOD)
5. Explain predictions with SHAP
6. Apply bias mitigation techniques
7. Compare fairness before vs after mitigation
8. Generate structured audit report
"""),

    md("## 0. Setup & Imports"),
    code("""import sys, warnings
sys.path.insert(0, '../src')
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['figure.dpi'] = 120

from data.generator import ClinicalDataGenerator
from data.preprocessor import ClinicalPreprocessor
from models.trainer import ClinicalModelTrainer
from fairness.metrics import FairnessAuditor, MultiGroupFairnessAuditor, format_fairness_report
from fairness.mitigation import CustomReweighing, GroupThresholdCalibrator, compare_mitigation_results
from visualization.plots import *
from utils.reporting import generate_audit_report

print("✅ All modules loaded successfully.")"""),

    md("""## 1. Synthetic Clinical Dataset Generation

We generate a realistic synthetic dataset with **intentionally injected demographic bias**.
The bias mimics documented real-world disparities in US healthcare:
- Black patients have higher readmission rates (partially due to socioeconomic factors)
- Patients in deprived ZIP codes have less access to preventive care

> **`bias_strength`**: Controls how strongly demographics affect outcomes.  
> `0.0` = no bias, `1.0` = extreme disparity.
"""),
    code("""# Generate 5000 synthetic patients with moderate bias
gen = ClinicalDataGenerator(n_samples=5000, bias_strength=0.7, random_state=42)
df = gen.generate()

print(f"Dataset shape: {df.shape}")
print(f"Overall readmission rate: {df['readmitted'].mean():.2%}")
print()
print("Readmission rate by RACE:")
print(df.groupby('race')['readmitted'].mean().sort_values(ascending=False).to_string())
print()
print("Readmission rate by ZIP group:")
print(df.groupby('zip_group')['readmitted'].mean().to_string())"""),

    code("""# Visualize demographic disparities
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# By race
race_rates = df.groupby('race')['readmitted'].mean().sort_values(ascending=False)
colors = ['#E84040' if v == race_rates.max() else '#2C3E7A' for v in race_rates.values]
axes[0].bar(race_rates.index, race_rates.values, color=colors, alpha=0.85, edgecolor='white')
axes[0].axhline(df['readmitted'].mean(), color='#F5A623', lw=2, linestyle='--', label='Overall rate')
axes[0].set_title('Readmission Rate by Race', fontweight='bold')
axes[0].set_ylabel('Readmission Rate')
axes[0].legend()
for i, (name, val) in enumerate(race_rates.items()):
    axes[0].text(i, val + 0.005, f'{val:.1%}', ha='center', fontweight='bold')

# By ZIP group
zip_rates = df.groupby('zip_group')['readmitted'].mean().sort_values(ascending=False)
axes[1].bar(zip_rates.index, zip_rates.values, color=['#E84040','#F5A623','#27AE60'], alpha=0.85)
axes[1].axhline(df['readmitted'].mean(), color='#2C3E7A', lw=2, linestyle='--', label='Overall rate')
axes[1].set_title('Readmission Rate by ZIP Group', fontweight='bold')
axes[1].set_ylabel('Readmission Rate')
axes[1].legend()

plt.suptitle('Dataset Bias Visualization', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.show()
print("\\n⚠️  Note: 'Black' patients and 'deprived' ZIP areas show elevated readmission rates.")
print("This disparity is partially caused by our injected bias (bias_strength=0.7).")"""),

    md("## 2. Data Preprocessing"),
    code("""preprocessor = ClinicalPreprocessor(test_size=0.2, random_state=42)
X_train, X_test, y_train, y_test, df_train, df_test = preprocessor.preprocess(df)
feature_names = preprocessor.get_feature_names()

print(f"Training samples: {len(X_train):,}")
print(f"Test samples:     {len(X_test):,}")
print(f"Features:         {len(feature_names)}")
print(f"Train class balance: {y_train.mean():.2%} positive")
print(f"Test class balance:  {y_test.mean():.2%} positive")"""),

    md("## 3. Model Training"),
    code("""# Train Logistic Regression baseline
trainer = ClinicalModelTrainer(model_name='logistic', model_dir='../models/')
trainer.train(X_train, y_train)
metrics = trainer.evaluate(X_test, y_test)

print("📊 Model Performance Metrics")
print("="*40)
for key in ['roc_auc', 'avg_precision', 'f1', 'precision', 'recall', 'accuracy', 'brier_score']:
    print(f"  {key:<20}: {metrics[key]:.4f}")"""),

    code("""# Feature importances from model coefficients
fi = trainer.get_feature_importances(feature_names)
if fi is not None:
    fig, ax = plt.subplots(figsize=(10, 6))
    top_fi = fi.head(15)
    ax.barh(top_fi['feature'][::-1], top_fi['importance'][::-1], color='#2C3E7A', alpha=0.8)
    ax.set_xlabel('|Coefficient|', fontsize=12)
    ax.set_title('Top 15 Feature Importances (Logistic Regression)', fontweight='bold')
    ax.grid(axis='x', alpha=0.3)
    plt.tight_layout()
    plt.show()"""),

    md("""## 4. Fairness Metrics — Before Mitigation

We audit the model using four canonical group fairness metrics:

| Metric | Definition | Fair Zone |
|--------|-----------|-----------|
| **Disparate Impact (DI)** | Ratio of favorable outcome rates: P(Ŷ=0\|unpriv) / P(Ŷ=0\|priv) | [0.80, 1.25] |
| **Statistical Parity Diff. (SPD)** | Difference in positive prediction rates | [-0.10, 0.10] |
| **Equal Opportunity Diff. (EOD)** | Difference in True Positive Rates | [-0.10, 0.10] |
| **Average Odds Diff. (AOD)** | Mean of TPR and FPR differences | [-0.10, 0.10] |

The **80% rule** (DI ≥ 0.8) is the standard legal threshold from US Equal Employment Opportunity Commission guidelines, widely adopted in AI fairness.
"""),
    code("""y_pred = trainer.predict(X_test)
y_proba = trainer.predict_proba(X_test)

# Audit by race (binary: White vs non-White)
auditor = FairnessAuditor(sensitive_col='race_binary', privileged_value=1)
fairness_before = auditor.compute_all(df_test, y_test, y_pred, y_proba)
print(format_fairness_report(fairness_before, model_name='Logistic Regression (Baseline)'))"""),

    code("""# Multi-group analysis across all racial groups
multi = MultiGroupFairnessAuditor(sensitive_col='race', label_col='readmitted')
mg_df = multi.compute(df_test, y_test, y_pred)
print("Per-race group metrics:")
display(mg_df.style.background_gradient(cmap='RdYlGn', axis=None).format('{:.4f}'))"""),

    code("""# Visualize fairness metrics
fig = plot_fairness_metrics(
    fairness_before,
    title='Fairness Metrics — Baseline Model (Before Mitigation)'
)
plt.show()"""),

    code("""# ROC by group
fig = plot_roc_by_group(df_test, y_test, y_proba, sensitive_col='race_binary')
plt.show()"""),

    md("## 5. SHAP Explainability"),
    code("""try:
    from explainability.shap_explainer import SHAPExplainer, BiasAttributionAnalyzer

    explainer = SHAPExplainer(trainer.model, feature_names, model_type='linear')
    explainer.fit(X_train, n_background=100)
    shap_values = explainer.explain(X_test, n_samples=500)
    shap_imp = explainer.get_global_importance()

    print("Top 10 features by mean |SHAP|:")
    display(shap_imp.head(10))

    fig = plot_shap_importance(shap_imp, title='Global Feature Importance (SHAP)')
    plt.show()

    # Bias attribution
    bias_analyzer = BiasAttributionAnalyzer(explainer)
    narrative = bias_analyzer.generate_bias_narrative(
        df_test.reset_index(drop=True).head(len(shap_values)),
        sensitive_col='race_binary'
    )
    print(narrative)

except ImportError:
    print("SHAP not installed. Run: pip install shap")"""),

    md("""## 6. Bias Mitigation

We apply two complementary strategies:

### 6a. Reweighing (Pre-processing)
Assigns sample weights to balance outcome distributions across groups.
No change to the data — only the training loss is reweighted.

**Reference:** Kamiran & Calders (2012)

### 6b. Group Threshold Calibration (Post-processing)
Sets a **different decision threshold** for each demographic group to achieve
equal True Positive Rates (equalized odds constraint).

**Reference:** Hardt, Price & Srebro (2016)
"""),
    code("""# 6a. Reweighing
reweigher = CustomReweighing(sensitive_col='race_binary', label_col='readmitted', privileged_value=1)
reweigher.fit(df_train)
sample_weights = reweigher.get_weights()

print(f"Sample weight range: [{sample_weights.min():.4f}, {sample_weights.max():.4f}]")
print(f"Mean weight: {sample_weights.mean():.4f}")

# Retrain with fairness weights
trainer_rw = ClinicalModelTrainer(model_name='logistic', model_dir='../models/')
trainer_rw.train(X_train, y_train)
trainer_rw.model.fit(X_train, y_train, sample_weight=sample_weights)
trainer_rw._trained = True

y_pred_rw = trainer_rw.predict(X_test)
y_proba_rw = trainer_rw.predict_proba(X_test)
fairness_rw = auditor.compute_all(df_test, y_test, y_pred_rw, y_proba_rw)
print(format_fairness_report(fairness_rw, model_name='Reweighted Model'))"""),

    code("""# 6b. Group Threshold Calibration
calibrator = GroupThresholdCalibrator(sensitive_col='race_binary', privileged_value=1)
calibrator.fit(df_test, y_test, y_proba)
y_pred_cal = calibrator.predict(df_test, y_proba)

print(f"Per-group thresholds: {calibrator.get_thresholds()}")

fairness_cal = auditor.compute_all(df_test, y_test, y_pred_cal, y_proba)
print(format_fairness_report(fairness_cal, model_name='Threshold-Calibrated Model'))"""),

    md("## 7. Before vs After Comparison"),
    code("""# Choose best mitigation
eod_rw  = abs(fairness_rw.get('equal_opportunity_difference', 999))
eod_cal = abs(fairness_cal.get('equal_opportunity_difference', 999))
fairness_after = fairness_cal if eod_cal < eod_rw else fairness_rw
method = 'Group Threshold Calibration' if eod_cal < eod_rw else 'Reweighing'
print(f"Best mitigation method: {method}")

comparison = compare_mitigation_results(fairness_before, fairness_after, method)
display(comparison.style.applymap(
    lambda v: 'background-color: #d4edda' if v is True else ('background-color: #f8d7da' if v is False else ''),
    subset=['improved']
))"""),

    code("""# Visual comparison
fig = plot_mitigation_comparison(
    comparison,
    title=f'Fairness Before vs After — {method}'
)
plt.show()"""),

    code("""# Dashboard summary
fig = plot_dashboard_summary(
    metrics_before=fairness_before,
    metrics_after=fairness_after,
    group_breakdown=fairness_before.get('group_breakdown', {}),
    model_name='Logistic Regression'
)
plt.show()"""),

    md("## 8. Audit Report Generation"),
    code("""report = generate_audit_report(
    model_metrics=metrics,
    fairness_before=fairness_before,
    fairness_after=fairness_after,
    mitigation_method=method,
    output_path='../reports/fairness_audit_report.md'
)
print(report[:2000])  # Print first 2000 chars
print("\\n[... truncated — see reports/fairness_audit_report.md for full report ...]")"""),

    md("""## 9. Summary & Conclusions

### What we found
- The baseline model exhibits **significant disparate impact** against non-White patients
- Equal opportunity difference indicates non-White patients are less likely to be correctly identified as high-risk
- SHAP analysis reveals `prior_admissions`, `creatinine`, and insurance type as key drivers of disparity

### What we did
- **Reweighing** redistributed training emphasis to underrepresented groups
- **Threshold calibration** adjusted decision boundaries per group to equalize TPR

### Key takeaways
> Bias in clinical AI is rarely intentional — it emerges from historical inequities in training data.
> Fixing it requires both technical intervention and domain expertise.

### Next steps
1. Audit for intersectional effects (e.g., race × insurance)
2. Conduct prospective clinical validation
3. Establish continuous fairness monitoring in production
4. Engage clinical ethicists and patient advocates in threshold decisions
"""),
]

# Save notebook
out_path = Path(__file__).parent / "fairness_audit_demo.ipynb"
with open(out_path, "w") as f:
    json.dump(nb, f, indent=1)
print(f"Notebook saved to {out_path}")
