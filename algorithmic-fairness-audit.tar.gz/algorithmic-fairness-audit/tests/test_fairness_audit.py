"""
Unit Tests for Healthcare AI Fairness Audit System.

Tests cover:
  - Synthetic data generation correctness
  - Fairness metric computation accuracy
  - Bias mitigation reweighing
  - Preprocessing pipeline integrity
"""

import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))

from data.generator import ClinicalDataGenerator
from data.preprocessor import ClinicalPreprocessor
from fairness.metrics import FairnessAuditor, MultiGroupFairnessAuditor, _tpr, _fpr, _ppv
from fairness.mitigation import CustomReweighing, GroupThresholdCalibrator, compare_mitigation_results
from models.trainer import ClinicalModelTrainer


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def small_dataset():
    """Generate a small reproducible dataset for testing."""
    gen = ClinicalDataGenerator(n_samples=500, bias_strength=0.5, random_state=0)
    return gen.generate()


@pytest.fixture(scope="module")
def preprocessed(small_dataset):
    """Return preprocessed train/test splits."""
    prep = ClinicalPreprocessor(test_size=0.25, random_state=0)
    X_train, X_test, y_train, y_test, df_train, df_test = prep.preprocess(small_dataset)
    return X_train, X_test, y_train, y_test, df_train, df_test, prep


@pytest.fixture(scope="module")
def trained_model(preprocessed):
    """Return a trained logistic regression model."""
    X_train, _, y_train, *_ = preprocessed
    trainer = ClinicalModelTrainer(model_name="logistic", model_dir="/tmp/test_models/")
    trainer.train(X_train, y_train)
    return trainer


# ── DATA GENERATOR TESTS ──────────────────────────────────────────────────────

class TestClinicalDataGenerator:
    def test_output_shape(self, small_dataset):
        assert len(small_dataset) == 500
        assert "readmitted" in small_dataset.columns
        assert "race" in small_dataset.columns
        assert "zip_group" in small_dataset.columns

    def test_label_binary(self, small_dataset):
        assert set(small_dataset["readmitted"].unique()).issubset({0, 1})

    def test_reproducibility(self):
        gen1 = ClinicalDataGenerator(n_samples=100, random_state=42)
        gen2 = ClinicalDataGenerator(n_samples=100, random_state=42)
        df1 = gen1.generate()
        df2 = gen2.generate()
        pd.testing.assert_frame_equal(df1, df2)

    def test_bias_injection_increases_disparity(self):
        gen_no_bias = ClinicalDataGenerator(n_samples=2000, bias_strength=0.0, random_state=1)
        gen_biased = ClinicalDataGenerator(n_samples=2000, bias_strength=1.0, random_state=1)
        df_nb = gen_no_bias.generate()
        df_b = gen_biased.generate()

        def disparity(df):
            rates = df.groupby("race")["readmitted"].mean()
            return rates.max() - rates.min()

        assert disparity(df_b) > disparity(df_nb), (
            "Biased dataset should have larger inter-group disparity"
        )

    def test_race_distribution(self, small_dataset):
        """White should be most common group."""
        race_counts = small_dataset["race"].value_counts()
        assert race_counts.idxmax() == "White"

    def test_valid_clinical_ranges(self, small_dataset):
        assert small_dataset["age"].between(18, 95).all()
        assert small_dataset["glucose"].between(60, 400).all()
        assert small_dataset["bmi"].between(15, 55).all()

    def test_dataset_summary(self, small_dataset):
        gen = ClinicalDataGenerator(n_samples=100, random_state=7)
        df = gen.generate()
        summary = gen.get_dataset_summary(df)
        assert "overall_readmission_rate" in summary
        assert "by_race" in summary
        assert 0.0 <= summary["overall_readmission_rate"] <= 1.0


# ── PREPROCESSING TESTS ───────────────────────────────────────────────────────

class TestClinicalPreprocessor:
    def test_split_sizes(self, preprocessed, small_dataset):
        X_train, X_test, *_ = preprocessed
        assert len(X_train) + len(X_test) == len(small_dataset)
        assert abs(len(X_test) / len(small_dataset) - 0.25) < 0.02

    def test_no_nan_in_features(self, preprocessed):
        X_train, X_test, *_ = preprocessed
        assert not np.isnan(X_train).any()
        assert not np.isnan(X_test).any()

    def test_scaling(self, preprocessed):
        X_train, X_test, *_ = preprocessed
        # Scaled training data should have ~zero mean
        assert abs(X_train.mean()) < 0.5

    def test_feature_names_returned(self, preprocessed):
        *_, prep = preprocessed
        features = prep.get_feature_names()
        assert isinstance(features, list)
        assert len(features) > 0
        assert all(isinstance(f, str) for f in features)

    def test_encoded_sensitive_attrs(self, preprocessed):
        *_, df_train, df_test, _ = preprocessed
        assert "race_binary" in df_train.columns
        assert "zip_binary" in df_train.columns
        assert set(df_train["race_binary"].unique()).issubset({0, 1})


# ── FAIRNESS METRIC TESTS ─────────────────────────────────────────────────────

class TestFairnessMetrics:
    def _make_scenario(self, tpr_priv=0.8, tpr_unpriv=0.5, fpr_priv=0.2, fpr_unpriv=0.3,
                       n=200, seed=42):
        """Build controlled predictions for metric testing."""
        rng = np.random.default_rng(seed)
        n_each = n // 2

        # Privileged group
        y_t_p = rng.binomial(1, 0.3, n_each)
        y_p_p = np.where(y_t_p == 1,
                         rng.binomial(1, tpr_priv, n_each),
                         rng.binomial(1, fpr_priv, n_each))

        # Unprivileged group
        y_t_u = rng.binomial(1, 0.3, n_each)
        y_p_u = np.where(y_t_u == 1,
                         rng.binomial(1, tpr_unpriv, n_each),
                         rng.binomial(1, fpr_unpriv, n_each))

        sensitive = np.concatenate([np.ones(n_each, dtype=int), np.zeros(n_each, dtype=int)])
        y_true = np.concatenate([y_t_p, y_t_u])
        y_pred = np.concatenate([y_p_p, y_p_u])
        df = pd.DataFrame({"race_binary": sensitive})
        return df, y_true, y_pred

    def test_tpr_computation(self):
        y_true = np.array([1, 1, 1, 0, 0])
        y_pred = np.array([1, 1, 0, 0, 0])
        assert abs(_tpr(y_true, y_pred) - 2 / 3) < 1e-9

    def test_fpr_computation(self):
        y_true = np.array([0, 0, 0, 1, 1])
        y_pred = np.array([1, 0, 0, 1, 0])
        assert abs(_fpr(y_true, y_pred) - 1 / 3) < 1e-9

    def test_ppv_computation(self):
        y_true = np.array([1, 0, 1, 0])
        y_pred = np.array([1, 1, 1, 0])
        assert abs(_ppv(y_true, y_pred) - 2 / 3) < 1e-9

    def test_eod_direction(self):
        """EOD should be negative when unprivileged group has lower TPR."""
        df, y_true, y_pred = self._make_scenario(tpr_priv=0.8, tpr_unpriv=0.5)
        auditor = FairnessAuditor(sensitive_col="race_binary", privileged_value=1)
        metrics = auditor.compute_all(df, y_true, y_pred)
        assert metrics["equal_opportunity_difference"] < 0, (
            "EOD should be negative when unprivileged group has lower TPR"
        )

    def test_disparate_impact_below_threshold_when_biased(self):
        """High-bias scenario should produce DI < 0.8."""
        df, y_true, y_pred = self._make_scenario(
            tpr_priv=0.9, tpr_unpriv=0.4, fpr_priv=0.1, fpr_unpriv=0.5
        )
        auditor = FairnessAuditor(sensitive_col="race_binary", privileged_value=1)
        metrics = auditor.compute_all(df, y_true, y_pred)
        # DI is ratio of favorable rates; highly biased should be low
        assert metrics["disparate_impact"] < 1.0

    def test_fairness_flags_structure(self):
        df, y_true, y_pred = self._make_scenario()
        auditor = FairnessAuditor(sensitive_col="race_binary", privileged_value=1)
        metrics = auditor.compute_all(df, y_true, y_pred)
        flags = metrics["fairness_flags"]
        assert "disparate_impact" in flags
        assert "equal_opportunity_difference" in flags
        assert "statistical_parity_difference" in flags

    def test_perfect_fairness(self):
        """Perfect parity → DI ~ 1.0, SPD ~ 0."""
        rng = np.random.default_rng(5)
        n = 400
        sensitive = np.concatenate([np.ones(n // 2, dtype=int), np.zeros(n // 2, dtype=int)])
        y_true = rng.binomial(1, 0.3, n)
        # Predictions identical in structure across groups
        y_pred = rng.binomial(1, 0.3, n)

        df = pd.DataFrame({"race_binary": sensitive})
        auditor = FairnessAuditor(sensitive_col="race_binary", privileged_value=1)
        metrics = auditor.compute_all(df, y_true, y_pred)
        # With random balanced predictions, SPD should be near 0
        assert abs(metrics["statistical_parity_difference"]) < 0.2

    def test_multi_group_auditor(self, small_dataset, preprocessed):
        X_train, X_test, y_train, y_test, df_train, df_test, prep = preprocessed
        trainer = ClinicalModelTrainer(model_name="logistic", model_dir="/tmp/")
        trainer.train(X_train, y_train)
        y_pred = trainer.predict(X_test)

        auditor = MultiGroupFairnessAuditor(sensitive_col="race")
        result = auditor.compute(df_test, y_test, y_pred)
        assert isinstance(result, pd.DataFrame)
        assert "accuracy" in result.columns
        assert "tpr" in result.columns
        assert len(result) >= 2


# ── MITIGATION TESTS ──────────────────────────────────────────────────────────

class TestBiasMitigation:
    def test_reweighing_weight_shape(self, small_dataset):
        prep = ClinicalPreprocessor(test_size=0.25, random_state=0)
        _, _, _, _, df_train, _, _ = prep.preprocess(small_dataset)
        rw = CustomReweighing(sensitive_col="race_binary", label_col="readmitted")
        rw.fit(df_train)
        weights = rw.get_weights()
        assert len(weights) == len(df_train)
        assert weights.min() > 0
        assert np.isfinite(weights).all()

    def test_reweighing_positive_weights(self, small_dataset):
        prep = ClinicalPreprocessor(test_size=0.25, random_state=0)
        _, _, _, _, df_train, _, _ = prep.preprocess(small_dataset)
        rw = CustomReweighing(sensitive_col="race_binary", label_col="readmitted")
        rw.fit(df_train)
        assert (rw.get_weights() > 0).all()

    def test_group_threshold_calibrator(self, preprocessed):
        X_train, X_test, y_train, y_test, df_train, df_test, prep = preprocessed
        trainer = ClinicalModelTrainer(model_name="logistic", model_dir="/tmp/")
        trainer.train(X_train, y_train)
        y_proba = trainer.predict_proba(X_test)

        cal = GroupThresholdCalibrator(sensitive_col="race_binary", privileged_value=1)
        cal.fit(df_test, y_test, y_proba)
        thresholds = cal.get_thresholds()
        assert len(thresholds) == 2
        for t in thresholds.values():
            assert 0.0 < t < 1.0

    def test_threshold_calibration_predict(self, preprocessed):
        X_train, X_test, y_train, y_test, df_train, df_test, prep = preprocessed
        trainer = ClinicalModelTrainer(model_name="logistic", model_dir="/tmp/")
        trainer.train(X_train, y_train)
        y_proba = trainer.predict_proba(X_test)

        cal = GroupThresholdCalibrator(sensitive_col="race_binary", privileged_value=1)
        cal.fit(df_test, y_test, y_proba)
        y_pred_cal = cal.predict(df_test, y_proba)
        assert len(y_pred_cal) == len(y_test)
        assert set(y_pred_cal).issubset({0, 1})

    def test_compare_mitigation_results(self):
        before = {"disparate_impact": 0.65, "equal_opportunity_difference": -0.25,
                  "statistical_parity_difference": -0.18, "average_odds_difference": -0.20,
                  "predictive_parity_difference": -0.10, "overall_accuracy": 0.78}
        after = {"disparate_impact": 0.88, "equal_opportunity_difference": -0.05,
                 "statistical_parity_difference": -0.04, "average_odds_difference": -0.04,
                 "predictive_parity_difference": -0.03, "overall_accuracy": 0.76}
        result = compare_mitigation_results(before, after, "Test Method")
        assert isinstance(result, pd.DataFrame)
        assert "before" in result.columns
        assert "after" in result.columns
        assert "delta" in result.columns
        assert result.loc["disparate_impact", "improved"] is True


# ── MODEL TESTS ───────────────────────────────────────────────────────────────

class TestModelTrainer:
    def test_training_and_prediction(self, preprocessed):
        X_train, X_test, y_train, y_test, *_ = preprocessed
        trainer = ClinicalModelTrainer(model_name="logistic", model_dir="/tmp/")
        trainer.train(X_train, y_train)
        preds = trainer.predict(X_test)
        assert len(preds) == len(y_test)
        assert set(preds).issubset({0, 1})

    def test_predict_proba_range(self, preprocessed):
        X_train, X_test, y_train, y_test, *_ = preprocessed
        trainer = ClinicalModelTrainer(model_name="logistic", model_dir="/tmp/")
        trainer.train(X_train, y_train)
        proba = trainer.predict_proba(X_test)
        assert ((proba >= 0) & (proba <= 1)).all()

    def test_evaluation_metrics_keys(self, preprocessed):
        X_train, X_test, y_train, y_test, *_ = preprocessed
        trainer = ClinicalModelTrainer(model_name="logistic", model_dir="/tmp/")
        trainer.train(X_train, y_train)
        metrics = trainer.evaluate(X_test, y_test)
        required_keys = ["roc_auc", "f1", "precision", "recall", "accuracy"]
        for k in required_keys:
            assert k in metrics, f"Missing key: {k}"

    def test_roc_auc_above_random(self, preprocessed):
        X_train, X_test, y_train, y_test, *_ = preprocessed
        trainer = ClinicalModelTrainer(model_name="logistic", model_dir="/tmp/")
        trainer.train(X_train, y_train)
        metrics = trainer.evaluate(X_test, y_test)
        assert metrics["roc_auc"] > 0.55, "Model AUC should be above random chance"

    def test_model_save_load(self, preprocessed, tmp_path):
        X_train, X_test, y_train, y_test, *_ = preprocessed
        trainer = ClinicalModelTrainer(model_name="logistic", model_dir=str(tmp_path))
        trainer.train(X_train, y_train)
        path = trainer.save()

        loaded = ClinicalModelTrainer.load(str(path), model_name="logistic")
        np.testing.assert_array_equal(
            trainer.predict(X_test), loaded.predict(X_test)
        )

    def test_untrained_raises(self, preprocessed):
        X_train, X_test, *_ = preprocessed
        trainer = ClinicalModelTrainer(model_name="logistic", model_dir="/tmp/")
        with pytest.raises(RuntimeError, match="not been trained"):
            trainer.predict(X_test)


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
