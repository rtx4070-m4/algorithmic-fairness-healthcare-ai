"""
Setup configuration for Algorithmic Fairness & Bias Auditing in Healthcare AI.
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="healthcare-fairness-audit",
    version="1.0.0",
    author="AI Fairness Research Team",
    author_email="fairness@research.ai",
    description="Algorithmic Fairness & Bias Auditing Framework for Healthcare AI",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/algorithmic-fairness-audit",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.9",
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "fairness-audit=scripts.run_full_audit:main",
        ],
    },
)
