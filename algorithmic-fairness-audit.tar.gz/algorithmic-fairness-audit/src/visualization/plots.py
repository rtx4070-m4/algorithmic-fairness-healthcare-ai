"""
Visualization Module for Fairness Audit Outputs.

All plotting functions save to file and optionally return the figure.
Designed for both notebook rendering and report generation.
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from pathlib import Path
from typing import Optional, Dict, List, Any, Tuple
import logging

logger = logging.getLogger(__name__)

# ── Styling ──────────────────────────────────────────────────────────────────
PALETTE = {
    "primary": "#2C3E7A",
    "secondary": "#E84040",
    "accent": "#F5A623",
    "success": "#27AE60",
    "neutral": "#7F8C8D",
    "light_bg": "#F8F9FA",
    "grid": "#E0E0E0",
}

GROUP_COLORS = {
    "privileged": PALETTE["primary"],
    "unprivileged": PALETTE["secondary"],
    "before": "#7F8C8D",
    "after": PALETTE["success"],
}


def _setup_style() -> None:
    plt.rcParams.update({
        "figure.facecolor": "white",
        "axes.facecolor": PALETTE["light_bg"],
        "axes.grid": True,
        "grid.color": PALETTE["grid"],
        "grid.linewidth": 0.6,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "font.family": "DejaVu Sans",
        "font.size": 11,
        "axes.labelsize": 12,
        "axes.titlesize": 14,
        "axes.titleweight": "bold",
    })


def _save(fig: plt.Figure, path: Optional[str]) -> None:
    if path:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(path, dpi=150, bbox_inches="tight", facecolor="white")
        logger.info(f"Plot saved: {path}")


# ── 1. Fairness Metrics Bar Chart ─────────────────────────────────────────────

def plot_fairness_metrics(
    metrics: Dict[str, float],
    title: str = "Fairness Metrics Overview",
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    Horizontal bar chart of key fairness metrics with threshold bands.

    Args:
        metrics: Dict mapping metric name to value.
        title: Plot title.
        save_path: Optional file path to save the figure.

    Returns:
        Matplotlib Figure.
    """
    _setup_style()

    metric_keys = [
        ("disparate_impact", "Disparate Impact", (0.8, 1.25)),
        ("statistical_parity_difference", "Statistical Parity Diff.", (-0.1, 0.1)),
        ("equal_opportunity_difference", "Equal Opportunity Diff.", (-0.1, 0.1)),
        ("average_odds_difference", "Average Odds Diff.", (-0.1, 0.1)),
        ("predictive_parity_difference", "Predictive Parity Diff.", (-0.1, 0.1)),
    ]

    labels, values, colors, thresholds = [], [], [], []
    for key, label, thresh in metric_keys:
        if key in metrics:
            val = metrics[key]
            labels.append(label)
            values.append(val)
            lo, hi = thresh
            is_fair = lo <= val <= hi
            colors.append(PALETTE["success"] if is_fair else PALETTE["secondary"])
            thresholds.append(thresh)

    fig, ax = plt.subplots(figsize=(10, 6))
    y_pos = np.arange(len(labels))

    bars = ax.barh(y_pos, values, color=colors, height=0.55, zorder=3)

    # Threshold bands
    for i, (lo, hi) in enumerate(thresholds):
        ax.axvspan(lo, hi, ymin=(i / len(labels)), ymax=((i + 1) / len(labels)),
                   alpha=0.08, color=PALETTE["success"], zorder=1)

    ax.axvline(0, color="black", linewidth=0.8, linestyle="--", zorder=4)

    # Value labels
    for bar, val in zip(bars, values):
        x_pos = val + 0.01 if val >= 0 else val - 0.01
        ha = "left" if val >= 0 else "right"
        ax.text(x_pos, bar.get_y() + bar.get_height() / 2,
                f"{val:.3f}", va="center", ha=ha, fontsize=10, fontweight="bold")

    ax.set_yticks(y_pos)
    ax.set_yticklabels(labels, fontsize=11)
    ax.set_xlabel("Metric Value")
    ax.set_title(title, pad=15)

    # Legend
    fair_patch = mpatches.Patch(color=PALETTE["success"], label="Fair (within threshold)")
    bias_patch = mpatches.Patch(color=PALETTE["secondary"], label="Biased (outside threshold)")
    band_patch = mpatches.Patch(color=PALETTE["success"], alpha=0.2, label="Fair zone")
    ax.legend(handles=[fair_patch, bias_patch, band_patch], loc="lower right", fontsize=9)

    fig.tight_layout()
    _save(fig, save_path)
    return fig


# ── 2. Group Comparison Chart ─────────────────────────────────────────────────

def plot_group_comparison(
    group_breakdown: Dict[str, Dict],
    title: str = "Group Performance Comparison",
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    Side-by-side grouped bar chart comparing metrics across demographic groups.

    Args:
        group_breakdown: Output of FairnessAuditor group_breakdown.
        title: Plot title.
        save_path: Optional save path.

    Returns:
        Matplotlib Figure.
    """
    _setup_style()
    metrics_to_plot = ["accuracy", "tpr", "fpr", "ppv", "positive_rate_pred"]
    metric_labels = ["Accuracy", "TPR (Recall)", "FPR", "Precision (PPV)", "Predicted Pos. Rate"]

    groups = list(group_breakdown.keys())
    x = np.arange(len(metrics_to_plot))
    width = 0.35

    fig, ax = plt.subplots(figsize=(12, 6))

    for i, group in enumerate(groups):
        vals = [group_breakdown[group].get(m, 0) for m in metrics_to_plot]
        offset = (i - len(groups) / 2 + 0.5) * width
        bars = ax.bar(x + offset, vals, width * 0.9, label=group.title(),
                      color=list(GROUP_COLORS.values())[i], alpha=0.85, zorder=3)
        for bar, val in zip(bars, vals):
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.005,
                    f"{val:.3f}", ha="center", va="bottom", fontsize=8.5, fontweight="bold")

    ax.set_xticks(x)
    ax.set_xticklabels(metric_labels, rotation=15, ha="right")
    ax.set_ylabel("Rate")
    ax.set_ylim(0, 1.12)
    ax.set_title(title, pad=15)
    ax.legend(fontsize=10)
    fig.tight_layout()
    _save(fig, save_path)
    return fig


# ── 3. Before/After Mitigation Comparison ────────────────────────────────────

def plot_mitigation_comparison(
    comparison_df: pd.DataFrame,
    title: str = "Fairness Before vs After Mitigation",
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    Grouped bar chart comparing fairness metrics before and after mitigation.

    Args:
        comparison_df: Output of compare_mitigation_results().
        title: Plot title.
        save_path: Optional save path.

    Returns:
        Matplotlib Figure.
    """
    _setup_style()
    df = comparison_df.reset_index()
    # Exclude accuracy from fairness metrics chart
    df = df[df["metric"] != "overall_accuracy"]

    x = np.arange(len(df))
    width = 0.35

    fig, ax = plt.subplots(figsize=(13, 6))
    ax.bar(x - width / 2, df["before"], width, label="Before", color=GROUP_COLORS["before"],
           alpha=0.85, zorder=3)
    ax.bar(x + width / 2, df["after"], width, label="After", color=GROUP_COLORS["after"],
           alpha=0.85, zorder=3)

    # Arrows showing direction of change
    for i, (b, a, improved) in enumerate(zip(df["before"], df["after"], df["improved"])):
        color = PALETTE["success"] if improved else PALETTE["secondary"]
        ax.annotate("", xy=(i + width / 2, a), xytext=(i - width / 2, b),
                    arrowprops=dict(arrowstyle="-|>", color=color, lw=1.5))

    ax.axhline(0, color="black", linewidth=0.8, linestyle="--")
    ax.set_xticks(x)
    ax.set_xticklabels(
        [m.replace("_", "\n") for m in df["metric"]], fontsize=9, ha="center"
    )
    ax.set_ylabel("Metric Value")
    ax.set_title(title, pad=15)
    ax.legend(fontsize=10)
    fig.tight_layout()
    _save(fig, save_path)
    return fig


# ── 4. Readmission Rate Disparity by Group ────────────────────────────────────

def plot_readmission_disparity(
    df: pd.DataFrame,
    group_col: str = "race",
    label_col: str = "readmitted",
    title: str = "Readmission Rate by Group",
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    Bar chart of outcome rates across all values of a categorical attribute.

    Args:
        df: Full dataset DataFrame.
        group_col: Column to group by.
        label_col: Binary outcome column.
        title: Plot title.
        save_path: Optional save path.

    Returns:
        Matplotlib Figure.
    """
    _setup_style()
    group_rates = df.groupby(group_col)[label_col].mean().sort_values(ascending=False)

    fig, ax = plt.subplots(figsize=(10, 5))
    colors = [PALETTE["secondary"] if v == group_rates.max() else
              PALETTE["primary"] for v in group_rates.values]
    bars = ax.bar(group_rates.index, group_rates.values, color=colors, alpha=0.85,
                  edgecolor="white", linewidth=1.2, zorder=3)

    overall = df[label_col].mean()
    ax.axhline(overall, color=PALETTE["accent"], linewidth=2, linestyle="--",
               label=f"Overall rate ({overall:.1%})", zorder=4)

    for bar, val in zip(bars, group_rates.values):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.005,
                f"{val:.1%}", ha="center", va="bottom", fontsize=11, fontweight="bold")

    ax.set_xlabel(group_col.replace("_", " ").title())
    ax.set_ylabel("Readmission Rate")
    ax.set_ylim(0, min(group_rates.max() * 1.25, 1.0))
    ax.set_title(title, pad=15)
    ax.legend(fontsize=10)
    fig.tight_layout()
    _save(fig, save_path)
    return fig


# ── 5. SHAP Feature Importance Plot ──────────────────────────────────────────

def plot_shap_importance(
    shap_importance_df: pd.DataFrame,
    top_k: int = 15,
    title: str = "Global Feature Importance (Mean |SHAP|)",
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    Horizontal bar chart of global SHAP feature importance.

    Args:
        shap_importance_df: Output of SHAPExplainer.get_global_importance().
        top_k: Number of top features to display.
        title: Plot title.
        save_path: Optional save path.

    Returns:
        Matplotlib Figure.
    """
    _setup_style()
    df = shap_importance_df.head(top_k).copy()

    fig, ax = plt.subplots(figsize=(10, 7))
    cmap = plt.cm.Blues
    max_val = df["mean_abs_shap"].max()
    colors = [cmap(0.4 + 0.6 * v / max_val) for v in df["mean_abs_shap"]]

    bars = ax.barh(df["feature"][::-1], df["mean_abs_shap"][::-1],
                   color=colors[::-1], height=0.6, zorder=3)

    for bar, val in zip(bars, df["mean_abs_shap"][::-1]):
        ax.text(bar.get_width() + max_val * 0.01, bar.get_y() + bar.get_height() / 2,
                f"{val:.4f}", va="center", fontsize=9)

    ax.set_xlabel("Mean |SHAP Value|")
    ax.set_title(title, pad=15)
    ax.set_xlim(0, max_val * 1.15)
    fig.tight_layout()
    _save(fig, save_path)
    return fig


# ── 6. SHAP Group Comparison ──────────────────────────────────────────────────

def plot_shap_group_comparison(
    priv_importance: pd.DataFrame,
    unpriv_importance: pd.DataFrame,
    top_k: int = 10,
    title: str = "SHAP Feature Importance: Privileged vs Unprivileged",
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    Side-by-side SHAP importance comparison between demographic groups.

    Args:
        priv_importance: SHAP importance for privileged group.
        unpriv_importance: SHAP importance for unprivileged group.
        top_k: Top features to show.
        title: Plot title.
        save_path: Optional save path.

    Returns:
        Matplotlib Figure.
    """
    _setup_style()

    # Align on top features from either group
    all_features = list(dict.fromkeys(
        list(priv_importance.index[:top_k]) + list(unpriv_importance.index[:top_k])
    ))[:top_k]

    priv_vals = [priv_importance.loc[f, "mean_abs_shap"] if f in priv_importance.index else 0
                 for f in all_features]
    unpriv_vals = [unpriv_importance.loc[f, "mean_abs_shap"] if f in unpriv_importance.index else 0
                   for f in all_features]

    x = np.arange(len(all_features))
    width = 0.38

    fig, ax = plt.subplots(figsize=(13, 7))
    ax.barh(x - width / 2, priv_vals, width, label="Privileged",
            color=PALETTE["primary"], alpha=0.85, zorder=3)
    ax.barh(x + width / 2, unpriv_vals, width, label="Unprivileged",
            color=PALETTE["secondary"], alpha=0.85, zorder=3)

    ax.set_yticks(x)
    ax.set_yticklabels(all_features, fontsize=10)
    ax.set_xlabel("Mean |SHAP Value|")
    ax.set_title(title, pad=15)
    ax.legend(fontsize=10)
    ax.axvline(0, color="black", linewidth=0.6)
    fig.tight_layout()
    _save(fig, save_path)
    return fig


# ── 7. ROC Curve by Group ────────────────────────────────────────────────────

def plot_roc_by_group(
    df: pd.DataFrame,
    y_true: np.ndarray,
    y_proba: np.ndarray,
    sensitive_col: str = "race_binary",
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    Plot ROC curves separately for privileged and unprivileged groups.

    Args:
        df: DataFrame with sensitive attribute.
        y_true: Ground truth labels.
        y_proba: Predicted probabilities.
        sensitive_col: Sensitive attribute column (binary).
        save_path: Optional save path.

    Returns:
        Matplotlib Figure.
    """
    from sklearn.metrics import roc_curve, auc
    _setup_style()

    fig, ax = plt.subplots(figsize=(8, 6))

    groups = {1: ("Privileged", PALETTE["primary"]), 0: ("Unprivileged", PALETTE["secondary"])}
    for val, (name, color) in groups.items():
        mask = (df[sensitive_col] == val).values
        if mask.sum() < 10:
            continue
        fpr, tpr, _ = roc_curve(y_true[mask], y_proba[mask])
        roc_auc = auc(fpr, tpr)
        ax.plot(fpr, tpr, color=color, lw=2.5,
                label=f"{name} (AUC = {roc_auc:.3f})")

    ax.plot([0, 1], [0, 1], "k--", lw=1, alpha=0.5, label="Random")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC Curve by Demographic Group", pad=15)
    ax.legend(fontsize=10, loc="lower right")
    ax.set_xlim([0, 1])
    ax.set_ylim([0, 1.02])
    fig.tight_layout()
    _save(fig, save_path)
    return fig


# ── 8. Calibration Plot by Group ─────────────────────────────────────────────

def plot_calibration_by_group(
    df: pd.DataFrame,
    y_true: np.ndarray,
    y_proba: np.ndarray,
    sensitive_col: str = "race_binary",
    n_bins: int = 10,
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    Calibration (reliability) curves for each demographic group.

    Args:
        df: DataFrame with sensitive attribute.
        y_true: Ground truth labels.
        y_proba: Predicted probabilities.
        sensitive_col: Sensitive attribute column.
        n_bins: Number of calibration bins.
        save_path: Optional save path.

    Returns:
        Matplotlib Figure.
    """
    from sklearn.calibration import calibration_curve
    _setup_style()

    fig, ax = plt.subplots(figsize=(8, 6))
    ax.plot([0, 1], [0, 1], "k--", lw=1, label="Perfect calibration")

    groups = {1: ("Privileged", PALETTE["primary"]), 0: ("Unprivileged", PALETTE["secondary"])}
    for val, (name, color) in groups.items():
        mask = (df[sensitive_col] == val).values
        if mask.sum() < 20:
            continue
        prob_true, prob_pred = calibration_curve(
            y_true[mask], y_proba[mask], n_bins=n_bins, strategy="quantile"
        )
        ax.plot(prob_pred, prob_true, "o-", color=color, lw=2, ms=6, label=name)

    ax.set_xlabel("Mean Predicted Probability")
    ax.set_ylabel("Fraction of Positives")
    ax.set_title("Calibration by Demographic Group", pad=15)
    ax.legend(fontsize=10)
    ax.set_xlim([0, 1])
    ax.set_ylim([0, 1])
    fig.tight_layout()
    _save(fig, save_path)
    return fig


# ── 9. Feature Distribution by Group ─────────────────────────────────────────

def plot_feature_distributions(
    df: pd.DataFrame,
    features: List[str],
    group_col: str = "race",
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    KDE/violin plots of key feature distributions across groups.

    Args:
        df: Full dataset DataFrame.
        features: List of numeric feature names to plot.
        group_col: Grouping column.
        save_path: Optional save path.

    Returns:
        Matplotlib Figure.
    """
    _setup_style()
    n = min(len(features), 6)
    features = features[:n]
    cols = 3
    rows = (n + cols - 1) // cols

    fig, axes = plt.subplots(rows, cols, figsize=(15, rows * 4))
    axes = np.array(axes).flatten()

    for i, feat in enumerate(features):
        ax = axes[i]
        groups = df[group_col].unique()
        palette = sns.color_palette("Set2", len(groups))
        for j, grp in enumerate(sorted(groups)):
            vals = df[df[group_col] == grp][feat].dropna()
            vals.plot.kde(ax=ax, label=grp, color=palette[j], linewidth=2)
        ax.set_title(feat.replace("_", " ").title())
        ax.set_xlabel("")
        ax.legend(fontsize=8)

    for ax in axes[n:]:
        ax.set_visible(False)

    fig.suptitle(f"Feature Distributions by {group_col.title()}", fontsize=15, fontweight="bold", y=1.01)
    fig.tight_layout()
    _save(fig, save_path)
    return fig


# ── 10. Disparity Dashboard (Summary Figure) ──────────────────────────────────

def plot_dashboard_summary(
    metrics_before: Dict,
    metrics_after: Dict,
    group_breakdown: Dict,
    model_name: str = "Baseline",
    save_path: Optional[str] = None,
) -> plt.Figure:
    """
    Multi-panel summary dashboard combining key fairness visualizations.

    Args:
        metrics_before: Fairness metrics before mitigation.
        metrics_after: Fairness metrics after mitigation.
        group_breakdown: Group-level breakdown dict.
        model_name: Model label for the title.
        save_path: Optional save path.

    Returns:
        Matplotlib Figure.
    """
    _setup_style()
    fig = plt.figure(figsize=(18, 12))
    fig.suptitle(
        f"Healthcare AI Fairness Audit Dashboard — {model_name}",
        fontsize=18, fontweight="bold", y=0.98
    )

    gs = fig.add_gridspec(2, 3, hspace=0.4, wspace=0.35)

    # Panel 1: Fairness metrics bar chart (before)
    ax1 = fig.add_subplot(gs[0, 0])
    _mini_fairness_bars(ax1, metrics_before, "Before Mitigation")

    # Panel 2: Fairness metrics bar chart (after)
    ax2 = fig.add_subplot(gs[0, 1])
    _mini_fairness_bars(ax2, metrics_after, "After Mitigation")

    # Panel 3: Group accuracy comparison
    ax3 = fig.add_subplot(gs[0, 2])
    _mini_group_comparison(ax3, group_breakdown)

    # Panel 4: Disparate Impact gauge
    ax4 = fig.add_subplot(gs[1, 0])
    _di_gauge(ax4, metrics_before.get("disparate_impact", 1.0),
              metrics_after.get("disparate_impact", 1.0))

    # Panel 5: EOD change
    ax5 = fig.add_subplot(gs[1, 1])
    _metric_change_chart(ax5, metrics_before, metrics_after)

    # Panel 6: Summary text
    ax6 = fig.add_subplot(gs[1, 2])
    ax6.axis("off")
    _summary_text_box(ax6, metrics_before, metrics_after)

    _save(fig, save_path)
    return fig


def _mini_fairness_bars(ax: plt.Axes, metrics: Dict, title: str) -> None:
    keys = ["disparate_impact", "statistical_parity_difference",
            "equal_opportunity_difference", "average_odds_difference"]
    short = ["DI", "SPD", "EOD", "AOD"]
    vals = [metrics.get(k, 0) for k in keys]
    thresholds = [(0.8, 1.25), (-0.1, 0.1), (-0.1, 0.1), (-0.1, 0.1)]
    colors = [PALETTE["success"] if (lo <= v <= hi) else PALETTE["secondary"]
              for v, (lo, hi) in zip(vals, thresholds)]
    bars = ax.bar(short, vals, color=colors, alpha=0.85, zorder=3)
    for bar, val in zip(bars, vals):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.005 if val >= 0 else bar.get_height() - 0.025,
                f"{val:.2f}", ha="center", va="bottom", fontsize=8, fontweight="bold")
    ax.axhline(0, color="black", linewidth=0.6, linestyle="--")
    ax.set_title(title, fontsize=10, fontweight="bold")
    ax.set_ylabel("Value", fontsize=9)


def _mini_group_comparison(ax: plt.Axes, group_breakdown: Dict) -> None:
    groups = list(group_breakdown.keys())
    metrics = ["accuracy", "tpr", "ppv"]
    labels = ["Accuracy", "TPR", "PPV"]
    x = np.arange(len(metrics))
    width = 0.3
    colors = [PALETTE["primary"], PALETTE["secondary"]]
    for i, grp in enumerate(groups):
        vals = [group_breakdown[grp].get(m, 0) for m in metrics]
        ax.bar(x + i * width, vals, width, label=grp.title(),
               color=colors[i % 2], alpha=0.85, zorder=3)
    ax.set_xticks(x + width / 2)
    ax.set_xticklabels(labels, fontsize=9)
    ax.set_title("Group Performance", fontsize=10, fontweight="bold")
    ax.set_ylim(0, 1.1)
    ax.legend(fontsize=8)


def _di_gauge(ax: plt.Axes, di_before: float, di_after: float) -> None:
    items = [("Before", di_before, PALETTE["neutral"]),
             ("After", di_after, PALETTE["success"])]
    for i, (label, val, color) in enumerate(items):
        ax.barh(i, val, color=color, alpha=0.8, height=0.4)
        ax.text(val + 0.01, i, f"{val:.3f}", va="center", fontsize=9, fontweight="bold")
    ax.axvspan(0.8, 1.25, alpha=0.12, color=PALETTE["success"])
    ax.axvline(1.0, color="gray", linewidth=0.8, linestyle="--")
    ax.set_yticks([0, 1])
    ax.set_yticklabels(["Before", "After"])
    ax.set_title("Disparate Impact", fontsize=10, fontweight="bold")
    ax.set_xlim(0, max(di_before, di_after) * 1.2)


def _metric_change_chart(ax: plt.Axes, before: Dict, after: Dict) -> None:
    keys = ["statistical_parity_difference", "equal_opportunity_difference", "average_odds_difference"]
    short = ["SPD", "EOD", "AOD"]
    deltas = [after.get(k, 0) - before.get(k, 0) for k in keys]
    colors = [PALETTE["success"] if abs(after.get(k, 0)) < abs(before.get(k, 0)) else PALETTE["secondary"]
              for k in keys]
    ax.bar(short, deltas, color=colors, alpha=0.85, zorder=3)
    ax.axhline(0, color="black", linewidth=0.6, linestyle="--")
    ax.set_title("Metric Change (After − Before)", fontsize=10, fontweight="bold")
    ax.set_ylabel("Delta")


def _summary_text_box(ax: plt.Axes, before: Dict, after: Dict) -> None:
    di_b = before.get("disparate_impact", float("nan"))
    di_a = after.get("disparate_impact", float("nan"))
    eod_b = before.get("equal_opportunity_difference", float("nan"))
    eod_a = after.get("equal_opportunity_difference", float("nan"))
    acc_b = before.get("overall_accuracy", float("nan"))
    acc_a = after.get("overall_accuracy", float("nan"))

    text = (
        "AUDIT SUMMARY\n"
        + "─" * 26 + "\n"
        f"DI:    {di_b:.3f} → {di_a:.3f}  {'✓' if 0.8 <= di_a <= 1.25 else '✗'}\n"
        f"EOD:   {eod_b:.3f} → {eod_a:.3f}  {'✓' if abs(eod_a) <= 0.1 else '✗'}\n"
        f"Acc:   {acc_b:.3f} → {acc_a:.3f}\n"
        + "─" * 26 + "\n"
        "✓ = within fair threshold\n"
        "✗ = outside fair threshold"
    )
    ax.text(0.05, 0.95, text, transform=ax.transAxes, fontsize=10,
            verticalalignment="top", fontfamily="monospace",
            bbox=dict(boxstyle="round", facecolor=PALETTE["light_bg"], alpha=0.8))
    ax.set_title("Summary", fontsize=10, fontweight="bold")
