"""
Model Training Module for Clinical Readmission Prediction.

Implements logistic regression (baseline) and Random Forest / XGBoost
classifiers with consistent interface, model persistence, and evaluation.
"""

import numpy as np
import pandas as pd
from typing import Dict, Any, Optional, Tuple
from pathlib import Path
import joblib
import logging

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (
    classification_report, roc_auc_score, confusion_matrix,
    average_precision_score, brier_score_loss
)
from sklearn.calibration import CalibratedClassifierCV

try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False

logger = logging.getLogger(__name__)


class ModelRegistry:
    """Central registry mapping model names to their constructors."""

    @staticmethod
    def get(name: str, **kwargs) -> Any:
        """
        Instantiate a model by name.

        Args:
            name: One of 'logistic', 'random_forest', 'gradient_boosting', 'xgboost'.
            **kwargs: Passed to the model constructor.

        Returns:
            Unfitted sklearn-compatible estimator.

        Raises:
            ValueError: If model name is unrecognized.
        """
        models = {
            "logistic": lambda: LogisticRegression(
                max_iter=1000, random_state=42, class_weight="balanced",
                solver="lbfgs", C=kwargs.get("C", 1.0)
            ),
            "random_forest": lambda: RandomForestClassifier(
                n_estimators=kwargs.get("n_estimators", 200),
                max_depth=kwargs.get("max_depth", 6),
                min_samples_leaf=2,
                class_weight="balanced",
                random_state=42,
                n_jobs=-1,
            ),
            "gradient_boosting": lambda: GradientBoostingClassifier(
                n_estimators=kwargs.get("n_estimators", 200),
                learning_rate=0.05,
                max_depth=4,
                random_state=42,
            ),
        }
        if XGBOOST_AVAILABLE:
            models["xgboost"] = lambda: XGBClassifier(
                n_estimators=kwargs.get("n_estimators", 200),
                max_depth=4,
                learning_rate=0.05,
                use_label_encoder=False,
                eval_metric="logloss",
                random_state=42,
                n_jobs=-1,
            )

        if name not in models:
            raise ValueError(
                f"Unknown model '{name}'. Available: {list(models.keys())}"
            )
        return models[name]()


class ClinicalModelTrainer:
    """
    Trains, evaluates, and persists clinical prediction models.

    Attributes:
        model_name (str): Name of the model architecture.
        model_dir (Path): Directory to save/load model artifacts.
        model: The underlying sklearn estimator.
    """

    def __init__(
        self,
        model_name: str = "logistic",
        model_dir: str = "models/",
        **model_kwargs: Any,
    ) -> None:
        self.model_name = model_name
        self.model_dir = Path(model_dir)
        self.model_dir.mkdir(parents=True, exist_ok=True)
        self.model = ModelRegistry.get(model_name, **model_kwargs)
        self._trained = False

    def train(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        calibrate: bool = False,
    ) -> "ClinicalModelTrainer":
        """
        Fit the model on training data.

        Args:
            X_train: Feature matrix.
            y_train: Binary labels.
            calibrate: If True, apply Platt scaling for probability calibration.

        Returns:
            self (for chaining).
        """
        logger.info(f"Training {self.model_name} model...")

        if calibrate and self.model_name != "logistic":
            self.model = CalibratedClassifierCV(self.model, cv=3, method="isotonic")

        self.model.fit(X_train, y_train)
        self._trained = True
        logger.info("Training complete.")
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Return binary predictions."""
        self._check_fitted()
        return self.model.predict(X)

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Return probability estimates."""
        self._check_fitted()
        return self.model.predict_proba(X)[:, 1]

    def evaluate(
        self,
        X_test: np.ndarray,
        y_test: np.ndarray,
        threshold: float = 0.5,
    ) -> Dict[str, Any]:
        """
        Compute a comprehensive evaluation report.

        Args:
            X_test: Test feature matrix.
            y_test: True binary labels.
            threshold: Classification threshold for binary predictions.

        Returns:
            Dictionary of evaluation metrics.
        """
        self._check_fitted()
        proba = self.predict_proba(X_test)
        y_pred = (proba >= threshold).astype(int)

        report = classification_report(y_test, y_pred, output_dict=True)
        cm = confusion_matrix(y_test, y_pred)
        tn, fp, fn, tp = cm.ravel()

        metrics = {
            "model_name": self.model_name,
            "roc_auc": roc_auc_score(y_test, proba),
            "avg_precision": average_precision_score(y_test, proba),
            "brier_score": brier_score_loss(y_test, proba),
            "accuracy": report["accuracy"],
            "precision": report["1"]["precision"],
            "recall": report["1"]["recall"],
            "f1": report["1"]["f1-score"],
            "specificity": tn / (tn + fp) if (tn + fp) > 0 else 0.0,
            "confusion_matrix": cm.tolist(),
            "threshold": threshold,
            "positive_rate": y_pred.mean(),
        }

        logger.info(
            f"[{self.model_name}] AUC={metrics['roc_auc']:.4f} | "
            f"F1={metrics['f1']:.4f} | "
            f"Precision={metrics['precision']:.4f} | "
            f"Recall={metrics['recall']:.4f}"
        )
        return metrics

    def predict_threshold_optimized(
        self,
        X: np.ndarray,
        y_true: np.ndarray,
        metric: str = "f1",
    ) -> Tuple[np.ndarray, float]:
        """
        Find the decision threshold that maximizes a given metric.

        Args:
            X: Feature matrix.
            y_true: True labels (for threshold search).
            metric: 'f1' or 'balanced_accuracy'.

        Returns:
            (predictions, optimal_threshold)
        """
        from sklearn.metrics import f1_score, balanced_accuracy_score
        proba = self.predict_proba(X)
        thresholds = np.linspace(0.1, 0.9, 81)
        score_fn = f1_score if metric == "f1" else balanced_accuracy_score
        scores = [score_fn(y_true, (proba >= t).astype(int)) for t in thresholds]
        best_threshold = thresholds[np.argmax(scores)]
        return (proba >= best_threshold).astype(int), best_threshold

    def save(self, filename: Optional[str] = None) -> Path:
        """
        Persist the model to disk.

        Args:
            filename: Override default filename.

        Returns:
            Path to the saved model file.
        """
        self._check_fitted()
        filename = filename or f"{self.model_name}_model.joblib"
        path = self.model_dir / filename
        joblib.dump(self.model, path)
        logger.info(f"Model saved to {path}")
        return path

    @classmethod
    def load(cls, path: str, model_name: str = "unknown") -> "ClinicalModelTrainer":
        """
        Load a persisted model from disk.

        Args:
            path: Path to the .joblib file.
            model_name: Descriptive name for the loaded model.

        Returns:
            ClinicalModelTrainer instance with loaded model.
        """
        trainer = cls.__new__(cls)
        trainer.model_name = model_name
        trainer.model_dir = Path(path).parent
        trainer.model = joblib.load(path)
        trainer._trained = True
        logger.info(f"Model loaded from {path}")
        return trainer

    def _check_fitted(self) -> None:
        if not self._trained:
            raise RuntimeError("Model has not been trained. Call .train() first.")

    def get_feature_importances(
        self, feature_names: list
    ) -> Optional[pd.DataFrame]:
        """
        Extract feature importances if the model supports it.

        Returns:
            DataFrame with feature names and importances, sorted descending.
        """
        model = self.model
        # Unwrap calibrated model
        if hasattr(model, "estimator"):
            model = model.estimator
        if hasattr(model, "base_estimator"):
            model = model.base_estimator

        if hasattr(model, "feature_importances_"):
            importance = model.feature_importances_
        elif hasattr(model, "coef_"):
            importance = np.abs(model.coef_[0])
        else:
            logger.warning(f"Model {self.model_name} does not expose feature importances.")
            return None

        df = pd.DataFrame(
            {"feature": feature_names, "importance": importance}
        ).sort_values("importance", ascending=False).reset_index(drop=True)
        return df
