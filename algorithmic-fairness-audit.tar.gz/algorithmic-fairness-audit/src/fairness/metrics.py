"""
Fairness Metrics Computation Module.

Implements a comprehensive suite of group fairness metrics using both
AIF360 (when available) and custom numpy/pandas implementations as fallback.

Metrics implemented:
  - Disparate Impact (DI)
  - Statistical Parity Difference (SPD)
  - Equal Opportunity Difference (EOD)
  - Average Odds Difference (AOD)
  - Predictive Parity Difference
  - Calibration by group
"""

import numpy as np
import pandas as pd
from typing import Dict, Optional, Tuple, List, Any
import logging

logger = logging.getLogger(__name__)

try:
    from aif360.datasets import BinaryLabelDataset
    from aif360.metrics import BinaryLabelDatasetMetric, ClassificationMetric
    AIF360_AVAILABLE = True
except ImportError:
    AIF360_AVAILABLE = False
    logger.warning("AIF360 not installed. Using fallback metric implementations.")


FAIRNESS_THRESHOLDS = {
    "disparate_impact": (0.8, 1.25),         # 80% rule: [0.8, 1.25]
    "statistical_parity_difference": (-0.1, 0.1),
    "equal_opportunity_difference": (-0.1, 0.1),
    "average_odds_difference": (-0.1, 0.1),
    "predictive_parity_difference": (-0.1, 0.1),
}


def _tpr(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """True positive rate (recall / sensitivity)."""
    tp = ((y_pred == 1) & (y_true == 1)).sum()
    fn = ((y_pred == 0) & (y_true == 1)).sum()
    return tp / (tp + fn) if (tp + fn) > 0 else 0.0


def _fpr(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """False positive rate."""
    fp = ((y_pred == 1) & (y_true == 0)).sum()
    tn = ((y_pred == 0) & (y_true == 0)).sum()
    return fp / (fp + tn) if (fp + tn) > 0 else 0.0


def _selection_rate(y_pred: np.ndarray) -> float:
    """Fraction predicted positive."""
    return y_pred.mean()


def _ppv(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Positive predictive value (precision)."""
    tp = ((y_pred == 1) & (y_true == 1)).sum()
    fp = ((y_pred == 1) & (y_true == 0)).sum()
    return tp / (tp + fp) if (tp + fp) > 0 else 0.0


class FairnessAuditor:
    """
    Computes group fairness metrics across a sensitive attribute.

    Supports both AIF360-based and custom numpy implementations.
    Provides interpretation flags based on configurable thresholds.

    Attributes:
        sensitive_col (str): Column name of the binarized sensitive attribute.
        privileged_value (int): Value indicating the privileged group (e.g., 1=White).
        label_col (str): Column name of the ground-truth label.
        pred_col (str): Column name of the predicted label.
    """

    def __init__(
        self,
        sensitive_col: str = "race_binary",
        privileged_value: int = 1,
        label_col: str = "readmitted",
        pred_col: str = "y_pred",
    ) -> None:
        self.sensitive_col = sensitive_col
        self.privileged_value = privileged_value
        self.label_col = label_col
        self.pred_col = pred_col

    def compute_all(
        self,
        df: pd.DataFrame,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        y_proba: Optional[np.ndarray] = None,
    ) -> Dict[str, Any]:
        """
        Compute the full suite of fairness metrics.

        Args:
            df: DataFrame containing the sensitive attribute column.
            y_true: Ground truth labels.
            y_pred: Model binary predictions.
            y_proba: Optional predicted probabilities.

        Returns:
            Dictionary of metric name -> value, plus group-level breakdowns.
        """
        results = df[[self.sensitive_col]].copy()
        results["y_true"] = y_true
        results["y_pred"] = y_pred
        if y_proba is not None:
            results["y_proba"] = y_proba

        priv_mask = results[self.sensitive_col] == self.privileged_value
        unpriv_mask = ~priv_mask

        priv = results[priv_mask]
        unpriv = results[unpriv_mask]

        metrics = self._compute_custom_metrics(priv, unpriv)
        metrics["group_breakdown"] = self._group_breakdown(results)
        metrics["fairness_flags"] = self._check_thresholds(metrics)
        metrics["overall_accuracy"] = (y_pred == y_true).mean()
        metrics["privileged_n"] = int(priv_mask.sum())
        metrics["unprivileged_n"] = int(unpriv_mask.sum())

        if AIF360_AVAILABLE:
            try:
                aif360_metrics = self._compute_aif360_metrics(df, y_true, y_pred)
                metrics["aif360"] = aif360_metrics
            except Exception as e:
                logger.warning(f"AIF360 metric computation failed: {e}")

        return metrics

    def _compute_custom_metrics(
        self, priv: pd.DataFrame, unpriv: pd.DataFrame
    ) -> Dict[str, float]:
        """Compute metrics using pure numpy/pandas."""
        priv_sr = _selection_rate(priv["y_pred"].values)
        unpriv_sr = _selection_rate(unpriv["y_pred"].values)

        priv_tpr = _tpr(priv["y_true"].values, priv["y_pred"].values)
        unpriv_tpr = _tpr(unpriv["y_true"].values, unpriv["y_pred"].values)

        priv_fpr = _fpr(priv["y_true"].values, priv["y_pred"].values)
        unpriv_fpr = _fpr(unpriv["y_true"].values, unpriv["y_pred"].values)

        priv_ppv = _ppv(priv["y_true"].values, priv["y_pred"].values)
        unpriv_ppv = _ppv(unpriv["y_true"].values, unpriv["y_pred"].values)

        # Disparate Impact (ratio of favorable outcome rates)
        # Here favorable = not readmitted = y_pred == 0
        priv_fav = 1 - priv_sr
        unpriv_fav = 1 - unpriv_sr
        di = (unpriv_fav / priv_fav) if priv_fav > 0 else np.nan

        spd = unpriv_sr - priv_sr
        eod = unpriv_tpr - priv_tpr
        aod = 0.5 * ((unpriv_fpr - priv_fpr) + (unpriv_tpr - priv_tpr))
        ppd = unpriv_ppv - priv_ppv

        return {
            "disparate_impact": round(di, 4),
            "statistical_parity_difference": round(spd, 4),
            "equal_opportunity_difference": round(eod, 4),
            "average_odds_difference": round(aod, 4),
            "predictive_parity_difference": round(ppd, 4),
            "privileged_selection_rate": round(priv_sr, 4),
            "unprivileged_selection_rate": round(unpriv_sr, 4),
            "privileged_tpr": round(priv_tpr, 4),
            "unprivileged_tpr": round(unpriv_tpr, 4),
            "privileged_fpr": round(priv_fpr, 4),
            "unprivileged_fpr": round(unpriv_fpr, 4),
            "privileged_ppv": round(priv_ppv, 4),
            "unprivileged_ppv": round(unpriv_ppv, 4),
        }

    def _group_breakdown(self, results: pd.DataFrame) -> Dict:
        """Compute per-group accuracy, TPR, FPR, and selection rate."""
        breakdown = {}
        for val, group_name in [(self.privileged_value, "privileged"), (1 - self.privileged_value, "unprivileged")]:
            mask = results[self.sensitive_col] == val
            g = results[mask]
            if len(g) == 0:
                continue
            breakdown[group_name] = {
                "n": len(g),
                "positive_rate_true": round(g["y_true"].mean(), 4),
                "positive_rate_pred": round(g["y_pred"].mean(), 4),
                "accuracy": round((g["y_true"] == g["y_pred"]).mean(), 4),
                "tpr": round(_tpr(g["y_true"].values, g["y_pred"].values), 4),
                "fpr": round(_fpr(g["y_true"].values, g["y_pred"].values), 4),
                "ppv": round(_ppv(g["y_true"].values, g["y_pred"].values), 4),
            }
        return breakdown

    def _check_thresholds(self, metrics: Dict) -> Dict[str, bool]:
        """
        Flag each metric as fair/unfair based on established thresholds.

        Returns:
            Dict of metric -> True (fair) / False (unfair).
        """
        flags = {}
        for metric, (low, high) in FAIRNESS_THRESHOLDS.items():
            val = metrics.get(metric)
            if val is not None and not np.isnan(val):
                flags[metric] = low <= val <= high
            else:
                flags[metric] = None
        return flags

    def _compute_aif360_metrics(
        self,
        df: pd.DataFrame,
        y_true: np.ndarray,
        y_pred: np.ndarray,
    ) -> Dict[str, float]:
        """Compute metrics via AIF360 ClassificationMetric."""
        from aif360.datasets import BinaryLabelDataset

        features = [c for c in df.columns if c not in ["readmitted", "y_pred"]]
        label_col = "readmitted"

        dataset_true = BinaryLabelDataset(
            df=pd.concat([
                df[[self.sensitive_col]].reset_index(drop=True),
                pd.Series(y_true, name=label_col),
            ], axis=1),
            label_names=[label_col],
            protected_attribute_names=[self.sensitive_col],
            favorable_label=0,
            unfavorable_label=1,
            privileged_protected_attributes=[[self.privileged_value]],
        )

        dataset_pred = dataset_true.copy()
        dataset_pred.labels = y_pred.reshape(-1, 1)

        privileged_groups = [{self.sensitive_col: self.privileged_value}]
        unprivileged_groups = [{self.sensitive_col: 1 - self.privileged_value}]

        metric = ClassificationMetric(
            dataset_true, dataset_pred,
            unprivileged_groups=unprivileged_groups,
            privileged_groups=privileged_groups,
        )

        return {
            "disparate_impact": round(metric.disparate_impact(), 4),
            "statistical_parity_difference": round(metric.statistical_parity_difference(), 4),
            "equal_opportunity_difference": round(metric.equal_opportunity_difference(), 4),
            "average_odds_difference": round(metric.average_odds_difference(), 4),
        }


class MultiGroupFairnessAuditor:
    """
    Extends fairness analysis to multiple groups within a categorical attribute.

    Useful for auditing across all racial groups (not just binary privileged/unprivileged).
    """

    def __init__(self, sensitive_col: str = "race", label_col: str = "readmitted") -> None:
        self.sensitive_col = sensitive_col
        self.label_col = label_col

    def compute(
        self,
        df: pd.DataFrame,
        y_true: np.ndarray,
        y_pred: np.ndarray,
    ) -> pd.DataFrame:
        """
        Compute per-group metrics across all unique values of the sensitive attribute.

        Returns:
            DataFrame with one row per group and metric columns.
        """
        results = df[[self.sensitive_col]].copy()
        results["y_true"] = y_true
        results["y_pred"] = y_pred

        rows = []
        for group in sorted(results[self.sensitive_col].unique()):
            mask = results[self.sensitive_col] == group
            g = results[mask]
            row = {
                "group": group,
                "n": len(g),
                "positive_rate_true": round(g["y_true"].mean(), 4),
                "positive_rate_pred": round(g["y_pred"].mean(), 4),
                "accuracy": round((g["y_true"] == g["y_pred"]).mean(), 4),
                "tpr": round(_tpr(g["y_true"].values, g["y_pred"].values), 4),
                "fpr": round(_fpr(g["y_true"].values, g["y_pred"].values), 4),
                "ppv": round(_ppv(g["y_true"].values, g["y_pred"].values), 4),
            }
            rows.append(row)

        return pd.DataFrame(rows).set_index("group")


def format_fairness_report(metrics: Dict, model_name: str = "Model") -> str:
    """
    Format a fairness metrics dictionary into a human-readable report string.

    Args:
        metrics: Output of FairnessAuditor.compute_all().
        model_name: Label for the model.

    Returns:
        Formatted report string.
    """
    lines = [
        f"\n{'='*60}",
        f"  FAIRNESS AUDIT REPORT — {model_name}",
        f"{'='*60}",
        f"\n  Overall Accuracy: {metrics.get('overall_accuracy', 'N/A'):.4f}",
        f"  Privileged (n={metrics.get('privileged_n', '?')}): selection rate = "
        f"{metrics.get('privileged_selection_rate', 'N/A'):.4f}",
        f"  Unprivileged (n={metrics.get('unprivileged_n', '?')}): selection rate = "
        f"{metrics.get('unprivileged_selection_rate', 'N/A'):.4f}",
        f"\n  {'METRIC':<40} {'VALUE':>10}  {'FAIR?':>6}",
        f"  {'-'*58}",
    ]

    flags = metrics.get("fairness_flags", {})
    metric_keys = [
        "disparate_impact",
        "statistical_parity_difference",
        "equal_opportunity_difference",
        "average_odds_difference",
        "predictive_parity_difference",
    ]

    for key in metric_keys:
        val = metrics.get(key, "N/A")
        fair = flags.get(key)
        fair_str = "✓ FAIR" if fair else ("✗ BIAS" if fair is not None else "  N/A ")
        val_str = f"{val:.4f}" if isinstance(val, float) else str(val)
        lines.append(f"  {key:<40} {val_str:>10}  {fair_str:>8}")

    lines += [
        f"\n  {'='*60}",
        f"  80% Rule (Disparate Impact): threshold [0.80, 1.25]",
        f"  Parity metrics: threshold [-0.10, 0.10]",
        f"{'='*60}\n",
    ]

    return "\n".join(lines)
