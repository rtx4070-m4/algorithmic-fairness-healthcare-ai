"""
Utility functions: logging setup, report generation, config management.
"""

import json
import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional


def setup_logging(level: str = "INFO", log_file: Optional[str] = None) -> None:
    """Configure root logger with console and optional file handler."""
    fmt = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    handlers = [logging.StreamHandler(sys.stdout)]
    if log_file:
        Path(log_file).parent.mkdir(parents=True, exist_ok=True)
        handlers.append(logging.FileHandler(log_file))
    logging.basicConfig(level=getattr(logging, level.upper()), format=fmt, handlers=handlers)


def save_json(data: Dict[str, Any], path: str) -> None:
    """Serialize a dict to JSON, handling numpy types."""
    import numpy as np

    class _Encoder(json.JSONEncoder):
        def default(self, obj):
            if isinstance(obj, (np.integer,)):
                return int(obj)
            if isinstance(obj, (np.floating,)):
                return float(obj)
            if isinstance(obj, np.ndarray):
                return obj.tolist()
            return super().default(obj)

    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2, cls=_Encoder)


def load_json(path: str) -> Dict:
    with open(path) as f:
        return json.load(f)


def generate_audit_report(
    model_metrics: Dict,
    fairness_before: Dict,
    fairness_after: Dict,
    mitigation_method: str,
    output_path: str = "reports/fairness_audit_report.md",
) -> str:
    """
    Generate a structured fairness audit report in Markdown format.

    Args:
        model_metrics: Classification performance metrics.
        fairness_before: Fairness metrics before mitigation.
        fairness_after: Fairness metrics after mitigation.
        mitigation_method: Name of the mitigation technique applied.
        output_path: File path to save the report.

    Returns:
        Report content as a string.
    """
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def _flag(val, lo, hi):
        if val is None:
            return "N/A"
        return "✅ FAIR" if lo <= val <= hi else "❌ BIASED"

    def _metric_row(name, before, after, lo, hi):
        b_flag = _flag(before, lo, hi)
        a_flag = _flag(after, lo, hi)
        delta = round(after - before, 4) if (before is not None and after is not None) else "N/A"
        return (f"| {name} | {before:.4f} | {b_flag} | "
                f"{after:.4f} | {a_flag} | {delta} |")

    lines = [
        f"# Healthcare AI Fairness Audit Report",
        f"",
        f"> **Generated:** {now}  ",
        f"> **Model:** {model_metrics.get('model_name', 'Unknown')}  ",
        f"> **Mitigation:** {mitigation_method}  ",
        f"",
        f"---",
        f"",
        f"## 1. Model Performance",
        f"",
        f"| Metric | Value |",
        f"|--------|-------|",
        f"| ROC-AUC | {model_metrics.get('roc_auc', 'N/A'):.4f} |",
        f"| F1-Score | {model_metrics.get('f1', 'N/A'):.4f} |",
        f"| Precision | {model_metrics.get('precision', 'N/A'):.4f} |",
        f"| Recall (TPR) | {model_metrics.get('recall', 'N/A'):.4f} |",
        f"| Accuracy | {model_metrics.get('accuracy', 'N/A'):.4f} |",
        f"| Brier Score | {model_metrics.get('brier_score', 'N/A'):.4f} |",
        f"",
        f"---",
        f"",
        f"## 2. Fairness Metrics: Before vs After Mitigation",
        f"",
        f"| Metric | Before | Status | After | Status | Δ Delta |",
        f"|--------|--------|--------|-------|--------|---------|",
        _metric_row("Disparate Impact", fairness_before.get("disparate_impact"),
                    fairness_after.get("disparate_impact"), 0.8, 1.25),
        _metric_row("Statistical Parity Diff.", fairness_before.get("statistical_parity_difference"),
                    fairness_after.get("statistical_parity_difference"), -0.1, 0.1),
        _metric_row("Equal Opportunity Diff.", fairness_before.get("equal_opportunity_difference"),
                    fairness_after.get("equal_opportunity_difference"), -0.1, 0.1),
        _metric_row("Average Odds Diff.", fairness_before.get("average_odds_difference"),
                    fairness_after.get("average_odds_difference"), -0.1, 0.1),
        _metric_row("Predictive Parity Diff.", fairness_before.get("predictive_parity_difference"),
                    fairness_after.get("predictive_parity_difference"), -0.1, 0.1),
        f"",
        f"---",
        f"",
        f"## 3. Group-Level Breakdown (After Mitigation)",
        f"",
        f"| Group | N | Accuracy | TPR | FPR | PPV | Pred. Pos. Rate |",
        f"|-------|---|----------|-----|-----|-----|-----------------|",
    ]

    for group, stats in fairness_after.get("group_breakdown", {}).items():
        lines.append(
            f"| {group.title()} | {stats.get('n','?')} | "
            f"{stats.get('accuracy','N/A'):.4f} | "
            f"{stats.get('tpr','N/A'):.4f} | "
            f"{stats.get('fpr','N/A'):.4f} | "
            f"{stats.get('ppv','N/A'):.4f} | "
            f"{stats.get('positive_rate_pred','N/A'):.4f} |"
        )

    lines += [
        f"",
        f"---",
        f"",
        f"## 4. Fairness Threshold Interpretation",
        f"",
        f"- **Disparate Impact:** Ratio of favorable outcome rates. Fair zone: [0.80, 1.25] (80% rule).",
        f"- **Statistical Parity Difference:** Difference in positive prediction rates. Fair zone: [-0.10, 0.10].",
        f"- **Equal Opportunity Difference:** Difference in TPR. Fair zone: [-0.10, 0.10].",
        f"- **Average Odds Difference:** Mean of FPR and TPR differences. Fair zone: [-0.10, 0.10].",
        f"- **Predictive Parity Difference:** Difference in precision. Fair zone: [-0.10, 0.10].",
        f"",
        f"---",
        f"",
        f"## 5. Mitigation Summary",
        f"",
        f"**Method applied:** {mitigation_method}",
        f"",
        f"Mitigation techniques used in this audit address bias at different pipeline stages:",
        f"- **Reweighing (pre-processing):** Assigns importance weights to training samples to balance",
        f"  outcome distributions across groups without altering the underlying data.",
        f"- **Group Threshold Calibration (post-processing):** Sets individualized decision thresholds",
        f"  per demographic group to achieve equalized odds.",
        f"",
        f"---",
        f"",
        f"## 6. Recommendations",
        f"",
        f"1. **Monitor continuously:** Fairness metrics should be tracked in production as data distributions shift.",
        f"2. **Stakeholder involvement:** Clinical domain experts and patient advocates should validate audit findings.",
        f"3. **Multi-attribute analysis:** Audit for intersectional effects (e.g., race × insurance status).",
        f"4. **Documentation:** All fairness decisions should be documented per AI governance standards.",
        f"",
        f"---",
        f"*This report was automatically generated by the Healthcare AI Fairness Audit System.*",
    ]

    report = "\n".join(lines)
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        f.write(report)

    return report
