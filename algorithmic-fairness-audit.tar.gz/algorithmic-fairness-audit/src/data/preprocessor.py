"""
Data Preprocessing Pipeline for Clinical Fairness Audit.

Handles encoding, scaling, train/test splitting, and preparation
of AIF360 BinaryLabelDataset objects for fairness analysis.
"""

import numpy as np
import pandas as pd
from typing import Tuple, List, Optional, Dict
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.pipeline import Pipeline
import logging

logger = logging.getLogger(__name__)

# Try importing AIF360; provide fallback if not installed
try:
    from aif360.datasets import BinaryLabelDataset
    AIF360_AVAILABLE = True
except ImportError:
    AIF360_AVAILABLE = False
    logger.warning("AIF360 not installed. Some fairness features will be unavailable.")


CATEGORICAL_FEATURES = ["sex", "insurance", "zip_group"]
SENSITIVE_ATTRIBUTES = ["race", "zip_group"]
LABEL_COLUMN = "readmitted"
DROP_COLUMNS = ["readmission_risk_prob"]  # Leakage prevention

FEATURE_COLUMNS = [
    "age", "glucose", "hba1c", "systolic_bp", "diastolic_bp",
    "bmi", "creatinine", "wbc", "hemoglobin",
    "diabetes", "hypertension", "heart_disease", "smoking",
    "prior_admissions", "length_of_stay", "num_medications",
    "emergency_visits", "sex_encoded", "insurance_encoded",
]


class ClinicalPreprocessor:
    """
    Preprocesses clinical data for model training and fairness evaluation.

    Encodes categorical variables, scales numeric features, and produces
    both sklearn-compatible arrays and AIF360 BinaryLabelDatasets.

    Attributes:
        test_size (float): Fraction of data for the test split.
        random_state (int): Reproducibility seed.
        scaler (StandardScaler): Fitted feature scaler.
        label_encoders (dict): Fitted encoders per categorical column.
    """

    def __init__(self, test_size: float = 0.2, random_state: int = 42) -> None:
        self.test_size = test_size
        self.random_state = random_state
        self.scaler = StandardScaler()
        self.label_encoders: Dict[str, LabelEncoder] = {}
        self._fitted = False

    def _encode_categoricals(
        self, df: pd.DataFrame, fit: bool = True
    ) -> pd.DataFrame:
        """Encode categorical features with label encoding."""
        df = df.copy()
        for col in CATEGORICAL_FEATURES:
            if col in df.columns:
                encoded_col = f"{col}_encoded"
                if fit:
                    le = LabelEncoder()
                    df[encoded_col] = le.fit_transform(df[col].astype(str))
                    self.label_encoders[col] = le
                else:
                    le = self.label_encoders[col]
                    df[encoded_col] = le.transform(df[col].astype(str))
        return df

    def _encode_race(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Binarize race for AIF360 (White=1, non-White=0).
        Also keep the original multi-class column.
        """
        df = df.copy()
        df["race_binary"] = (df["race"] == "White").astype(int)
        return df

    def _encode_zip(self, df: pd.DataFrame) -> pd.DataFrame:
        """Binarize zip_group (affluent=1, else=0)."""
        df = df.copy()
        df["zip_binary"] = (df["zip_group"] == "affluent").astype(int)
        return df

    def preprocess(
        self, df: pd.DataFrame
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, pd.DataFrame, pd.DataFrame]:
        """
        Run the full preprocessing pipeline.

        Args:
            df: Raw clinical DataFrame.

        Returns:
            X_train, X_test, y_train, y_test, df_train, df_test
        """
        df = df.copy()

        # Drop leakage columns
        df.drop(columns=[c for c in DROP_COLUMNS if c in df.columns], inplace=True)

        # Add encoded sensitive attrs
        df = self._encode_race(df)
        df = self._encode_zip(df)
        df = self._encode_categoricals(df, fit=True)

        # Split before scaling
        df_train, df_test = train_test_split(
            df, test_size=self.test_size, random_state=self.random_state,
            stratify=df[LABEL_COLUMN]
        )

        # Get feature columns present in data
        feat_cols = [c for c in FEATURE_COLUMNS if c in df.columns]

        X_train = df_train[feat_cols].values
        X_test = df_test[feat_cols].values
        y_train = df_train[LABEL_COLUMN].values
        y_test = df_test[LABEL_COLUMN].values

        # Scale
        X_train = self.scaler.fit_transform(X_train)
        X_test = self.scaler.transform(X_test)

        self._fitted = True
        self._feat_cols = feat_cols
        logger.info(
            f"Preprocessing complete. Train: {len(X_train)}, Test: {len(X_test)}, "
            f"Features: {len(feat_cols)}"
        )
        return X_train, X_test, y_train, y_test, df_train, df_test

    def get_feature_names(self) -> List[str]:
        """Return feature column names after preprocessing."""
        return self._feat_cols

    def make_aif360_dataset(
        self,
        df: pd.DataFrame,
        sensitive_attribute: str = "race_binary",
        privileged_value: int = 1,
    ):
        """
        Construct an AIF360 BinaryLabelDataset from a preprocessed DataFrame.

        Args:
            df: Preprocessed DataFrame (output of preprocess()).
            sensitive_attribute: Column name of the binarized sensitive attr.
            privileged_value: Value representing the privileged group.

        Returns:
            AIF360 BinaryLabelDataset instance, or None if AIF360 unavailable.
        """
        if not AIF360_AVAILABLE:
            logger.error("AIF360 not available. Cannot create BinaryLabelDataset.")
            return None

        feat_cols = [c for c in FEATURE_COLUMNS if c in df.columns]
        all_cols = feat_cols + [sensitive_attribute, LABEL_COLUMN]
        subset = df[[c for c in all_cols if c in df.columns]].copy()

        dataset = BinaryLabelDataset(
            df=subset,
            label_names=[LABEL_COLUMN],
            protected_attribute_names=[sensitive_attribute],
            favorable_label=0,   # 0 = not readmitted (favorable outcome)
            unfavorable_label=1, # 1 = readmitted (unfavorable outcome)
            privileged_protected_attributes=[[privileged_value]],
        )
        return dataset
