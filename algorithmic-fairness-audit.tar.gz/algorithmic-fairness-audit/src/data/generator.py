"""
Synthetic Clinical Dataset Generator with Controlled Bias Injection.

Generates realistic clinical data for healthcare AI fairness research,
with configurable bias patterns across sensitive attributes such as
race and ZIP code (socioeconomic proxy).
"""

import numpy as np
import pandas as pd
from typing import Optional, Tuple, Dict
import logging

logger = logging.getLogger(__name__)


class ClinicalDataGenerator:
    """
    Generates a synthetic clinical dataset with injected demographic bias.

    The dataset simulates a binary clinical outcome (e.g., readmission risk)
    with features drawn from realistic clinical distributions. Bias is
    injected by modulating outcome probabilities based on sensitive attributes
    (race and ZIP code), mirroring documented real-world disparities.

    Attributes:
        n_samples (int): Total number of patient records to generate.
        bias_strength (float): Magnitude of injected bias [0.0 = none, 1.0 = extreme].
        random_state (int): Seed for reproducibility.
    """

    RACES = ["White", "Black", "Hispanic", "Asian", "Other"]
    RACE_BIAS_FACTORS = {
        "White": 0.0,
        "Black": 0.25,
        "Hispanic": 0.18,
        "Asian": -0.05,
        "Other": 0.10,
    }

    ZIP_GROUPS = ["affluent", "middle", "deprived"]
    ZIP_BIAS_FACTORS = {
        "affluent": -0.10,
        "middle": 0.05,
        "deprived": 0.22,
    }

    def __init__(
        self,
        n_samples: int = 5000,
        bias_strength: float = 0.7,
        random_state: int = 42,
    ) -> None:
        self.n_samples = n_samples
        self.bias_strength = bias_strength
        self.random_state = random_state
        self._rng = np.random.default_rng(random_state)

    def _generate_demographics(self) -> pd.DataFrame:
        """Generate sensitive demographic attributes."""
        race = self._rng.choice(
            self.RACES,
            size=self.n_samples,
            p=[0.60, 0.13, 0.18, 0.06, 0.03],
        )
        zip_group = self._rng.choice(
            self.ZIP_GROUPS,
            size=self.n_samples,
            p=[0.30, 0.45, 0.25],
        )
        age = self._rng.normal(loc=58, scale=15, size=self.n_samples).clip(18, 95)
        sex = self._rng.choice(["Male", "Female"], size=self.n_samples, p=[0.48, 0.52])
        return pd.DataFrame({"race": race, "zip_group": zip_group, "age": age, "sex": sex})

    def _generate_clinical_features(self, demographics: pd.DataFrame) -> pd.DataFrame:
        """Generate realistic clinical feature distributions."""
        n = self.n_samples

        # Lab values with mild demographic correlation
        glucose = self._rng.normal(110, 30, n).clip(60, 400)
        hba1c = self._rng.normal(6.8, 1.5, n).clip(4.0, 14.0)
        systolic_bp = self._rng.normal(130, 20, n).clip(80, 200)
        diastolic_bp = self._rng.normal(82, 12, n).clip(50, 130)
        bmi = self._rng.normal(28.5, 6.0, n).clip(15, 55)
        creatinine = self._rng.lognormal(np.log(1.0), 0.35, n).clip(0.4, 8.0)
        wbc = self._rng.normal(7.5, 2.5, n).clip(2.0, 25.0)
        hemoglobin = self._rng.normal(13.5, 2.0, n).clip(6.0, 18.0)

        # Comorbidities (binary) — rates vary by ZIP group
        deprived_mask = (demographics["zip_group"] == "deprived").values
        diabetes_base = 0.18 + 0.12 * deprived_mask
        hypertension_base = 0.32 + 0.10 * deprived_mask

        diabetes = self._rng.binomial(1, diabetes_base.clip(0, 1), n)
        hypertension = self._rng.binomial(1, hypertension_base.clip(0, 1), n)
        heart_disease = self._rng.binomial(1, 0.12, n)
        smoking = self._rng.binomial(1, 0.20, n)

        # Healthcare utilization
        prior_admissions = self._rng.poisson(1.5, n)
        length_of_stay = self._rng.exponential(4.5, n).clip(1, 45).astype(int)
        num_medications = self._rng.poisson(5.5, n).clip(0, 20)
        emergency_visits = self._rng.poisson(0.8, n)

        # Insurance type correlated with ZIP
        insurance_probs = {
            "affluent": [0.70, 0.20, 0.10],
            "middle": [0.45, 0.40, 0.15],
            "deprived": [0.15, 0.55, 0.30],
        }
        insurance = np.array([
            self._rng.choice(
                ["Private", "Medicare/Medicaid", "Uninsured"],
                p=insurance_probs[z],
            )
            for z in demographics["zip_group"]
        ])

        return pd.DataFrame({
            "glucose": glucose,
            "hba1c": hba1c,
            "systolic_bp": systolic_bp,
            "diastolic_bp": diastolic_bp,
            "bmi": bmi,
            "creatinine": creatinine,
            "wbc": wbc,
            "hemoglobin": hemoglobin,
            "diabetes": diabetes,
            "hypertension": hypertension,
            "heart_disease": heart_disease,
            "smoking": smoking,
            "prior_admissions": prior_admissions,
            "length_of_stay": length_of_stay,
            "num_medications": num_medications,
            "emergency_visits": emergency_visits,
            "insurance": insurance,
        })

    def _inject_bias(
        self,
        demographics: pd.DataFrame,
        clinical: pd.DataFrame,
    ) -> np.ndarray:
        """
        Compute biased outcome probabilities.

        The base probability reflects clinical risk factors. Bias is then
        additively injected based on race and ZIP group using configurable
        multiplicative strength, simulating systemic health disparities.

        Args:
            demographics: DataFrame of demographic features.
            clinical: DataFrame of clinical features.

        Returns:
            Array of readmission probabilities per patient.
        """
        # Base risk from clinical features (logistic-like)
        risk_score = (
            0.01 * (demographics["age"] - 60) / 10
            + 0.08 * clinical["diabetes"]
            + 0.06 * clinical["heart_disease"]
            + 0.05 * clinical["hypertension"]
            + 0.03 * clinical["smoking"]
            + 0.04 * np.log1p(clinical["prior_admissions"])
            + 0.02 * np.log1p(clinical["emergency_visits"])
            + 0.005 * (clinical["creatinine"] - 1.0)
            + 0.003 * (clinical["glucose"] - 100) / 10
        )

        base_prob = 1 / (1 + np.exp(-risk_score))  # sigmoid

        # Bias injection
        race_bias = np.array([
            self.RACE_BIAS_FACTORS[r] for r in demographics["race"]
        ])
        zip_bias = np.array([
            self.ZIP_BIAS_FACTORS[z] for z in demographics["zip_group"]
        ])

        biased_prob = base_prob + self.bias_strength * (race_bias + zip_bias)
        return np.clip(biased_prob, 0.02, 0.98)

    def generate(self, save_path: Optional[str] = None) -> pd.DataFrame:
        """
        Generate the full synthetic clinical dataset.

        Args:
            save_path: Optional CSV file path to save the dataset.

        Returns:
            Complete DataFrame with demographics, clinical features, and outcome.
        """
        logger.info(f"Generating {self.n_samples} synthetic patient records...")

        demographics = self._generate_demographics()
        clinical = self._generate_clinical_features(demographics)
        probs = self._inject_bias(demographics, clinical)

        readmitted = self._rng.binomial(1, probs).astype(int)

        df = pd.concat([demographics, clinical], axis=1)
        df["readmission_risk_prob"] = probs  # For analysis only
        df["readmitted"] = readmitted

        logger.info(
            f"Dataset generated. Readmission rate: {readmitted.mean():.2%}. "
            f"Bias strength: {self.bias_strength}"
        )

        if save_path:
            df.to_csv(save_path, index=False)
            logger.info(f"Dataset saved to {save_path}")

        return df

    def get_dataset_summary(self, df: pd.DataFrame) -> Dict:
        """Return summary statistics grouped by sensitive attributes."""
        summary = {
            "overall_readmission_rate": df["readmitted"].mean(),
            "by_race": df.groupby("race")["readmitted"].mean().to_dict(),
            "by_zip_group": df.groupby("zip_group")["readmitted"].mean().to_dict(),
            "n_samples": len(df),
            "bias_strength": self.bias_strength,
        }
        return summary


def load_or_generate(
    csv_path: str,
    n_samples: int = 5000,
    bias_strength: float = 0.7,
    random_state: int = 42,
) -> pd.DataFrame:
    """
    Load dataset from CSV if it exists, else generate and save it.

    Args:
        csv_path: Path to the CSV file.
        n_samples: Number of samples to generate if not found.
        bias_strength: Bias injection magnitude.
        random_state: Random seed.

    Returns:
        Clinical dataset as a DataFrame.
    """
    import os
    if os.path.exists(csv_path):
        logger.info(f"Loading existing dataset from {csv_path}")
        return pd.read_csv(csv_path)

    gen = ClinicalDataGenerator(
        n_samples=n_samples,
        bias_strength=bias_strength,
        random_state=random_state,
    )
    return gen.generate(save_path=csv_path)
