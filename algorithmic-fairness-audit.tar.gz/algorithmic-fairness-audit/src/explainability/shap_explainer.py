"""
SHAP-based Explainability Module for Clinical Fairness Audit.

Provides SHAP explanations at global (feature importance) and local
(individual prediction) levels, with fairness-aware interpretation:
identifying which features drive disparities across demographic groups.
"""

import numpy as np
import pandas as pd
from typing import Optional, List, Dict, Any, Tuple
import logging
import warnings

logger = logging.getLogger(__name__)

try:
    import shap
    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False
    logger.warning("SHAP not installed. Explainability features unavailable.")


class SHAPExplainer:
    """
    Wrapper around SHAP explainers for clinical model interpretation.

    Automatically selects the appropriate SHAP explainer based on
    model type (TreeExplainer for tree models, LinearExplainer for
    logistic regression, KernelExplainer as fallback).

    Attributes:
        model: Fitted sklearn-compatible estimator.
        feature_names (list): Names of input features.
        explainer: Fitted SHAP explainer instance.
        shap_values (np.ndarray): Computed SHAP values.
    """

    def __init__(
        self,
        model,
        feature_names: List[str],
        model_type: str = "auto",
    ) -> None:
        if not SHAP_AVAILABLE:
            raise ImportError("SHAP must be installed: pip install shap")
        self.model = model
        self.feature_names = feature_names
        self.model_type = model_type
        self.explainer = None
        self.shap_values: Optional[np.ndarray] = None
        self._background_data: Optional[np.ndarray] = None

    def fit(
        self,
        X_background: np.ndarray,
        n_background: int = 100,
    ) -> "SHAPExplainer":
        """
        Initialize and fit the SHAP explainer on background data.

        Args:
            X_background: Training data used as background / reference.
            n_background: Number of background samples (KernelExplainer).

        Returns:
            self
        """
        # Subsample background for efficiency
        if len(X_background) > n_background:
            idx = np.random.choice(len(X_background), n_background, replace=False)
            background = X_background[idx]
        else:
            background = X_background
        self._background_data = background

        model_type = self._detect_model_type() if self.model_type == "auto" else self.model_type

        logger.info(f"Initializing {model_type} SHAP explainer...")

        if model_type == "tree":
            self.explainer = shap.TreeExplainer(self.model)
        elif model_type == "linear":
            self.explainer = shap.LinearExplainer(
                self.model, background, feature_perturbation="interventional"
            )
        else:
            self.explainer = shap.KernelExplainer(
                self.model.predict_proba, background
            )

        logger.info("SHAP explainer initialized.")
        return self

    def explain(
        self,
        X: np.ndarray,
        n_samples: Optional[int] = None,
        check_additivity: bool = False,
    ) -> np.ndarray:
        """
        Compute SHAP values for a dataset.

        Args:
            X: Feature matrix to explain.
            n_samples: Subsample size (for speed). None = use all.
            check_additivity: SHAP additivity check (may fail for some models).

        Returns:
            SHAP values array of shape (n_samples, n_features).
        """
        if self.explainer is None:
            raise RuntimeError("Call fit() before explain().")

        if n_samples and len(X) > n_samples:
            idx = np.random.choice(len(X), n_samples, replace=False)
            X_sub = X[idx]
        else:
            X_sub = X

        logger.info(f"Computing SHAP values for {len(X_sub)} samples...")

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            if isinstance(self.explainer, shap.TreeExplainer):
                sv = self.explainer.shap_values(X_sub, check_additivity=check_additivity)
                # For binary classification, take class-1 SHAP values
                if isinstance(sv, list):
                    sv = sv[1]
            elif isinstance(self.explainer, shap.KernelExplainer):
                sv = self.explainer.shap_values(X_sub, nsamples=50)
                if isinstance(sv, list):
                    sv = sv[1]
            else:
                sv = self.explainer.shap_values(X_sub)
                if isinstance(sv, list):
                    sv = sv[1]

        self.shap_values = sv
        self._explained_X = X_sub
        logger.info(f"SHAP values computed. Shape: {sv.shape}")
        return sv

    def get_global_importance(self) -> pd.DataFrame:
        """
        Compute global feature importance as mean absolute SHAP value.

        Returns:
            DataFrame with feature names and mean |SHAP| values, sorted descending.
        """
        if self.shap_values is None:
            raise RuntimeError("Call explain() first.")
        mean_abs = np.abs(self.shap_values).mean(axis=0)
        df = pd.DataFrame({
            "feature": self.feature_names,
            "mean_abs_shap": mean_abs,
        }).sort_values("mean_abs_shap", ascending=False).reset_index(drop=True)
        return df

    def get_group_shap_comparison(
        self,
        df_meta: pd.DataFrame,
        sensitive_col: str = "race_binary",
        privileged_value: int = 1,
    ) -> Dict[str, pd.DataFrame]:
        """
        Compare SHAP feature importance between demographic groups.

        Reveals which features drive disparate predictions — a key
        tool for bias attribution in clinical models.

        Args:
            df_meta: DataFrame with sensitive attribute (aligned with explained X).
            sensitive_col: Column to split groups on.
            privileged_value: Value of privileged group.

        Returns:
            Dict with keys 'privileged', 'unprivileged', 'difference'.
        """
        if self.shap_values is None:
            raise RuntimeError("Call explain() first.")

        # Align metadata with explained samples
        meta = df_meta.reset_index(drop=True)
        if len(meta) != len(self.shap_values):
            # If subsampled, we can't align — return global only
            logger.warning("Metadata length mismatch. Returning global importance only.")
            return {"global": self.get_global_importance()}

        priv_mask = meta[sensitive_col] == privileged_value

        def _group_importance(mask: pd.Series) -> pd.DataFrame:
            sv = self.shap_values[mask.values]
            mean_abs = np.abs(sv).mean(axis=0)
            return pd.DataFrame({
                "feature": self.feature_names,
                "mean_abs_shap": mean_abs,
            }).set_index("feature")

        priv_imp = _group_importance(priv_mask)
        unpriv_imp = _group_importance(~priv_mask)
        diff = (unpriv_imp - priv_imp).rename(columns={"mean_abs_shap": "shap_diff"})

        return {
            "privileged": priv_imp.sort_values("mean_abs_shap", ascending=False),
            "unprivileged": unpriv_imp.sort_values("mean_abs_shap", ascending=False),
            "difference": diff.sort_values("shap_diff", ascending=False, key=abs),
        }

    def explain_individual(self, x: np.ndarray) -> Dict[str, Any]:
        """
        Explain a single prediction with feature-level SHAP contributions.

        Args:
            x: Single feature vector (1D array).

        Returns:
            Dict with feature names, SHAP values, and base value.
        """
        if self.explainer is None:
            raise RuntimeError("Call fit() first.")
        x_2d = x.reshape(1, -1)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            sv = self.explainer.shap_values(x_2d)
        if isinstance(sv, list):
            sv = sv[1]
        sv = sv.flatten()
        base = (
            self.explainer.expected_value[1]
            if isinstance(self.explainer.expected_value, (list, np.ndarray))
            else self.explainer.expected_value
        )
        return {
            "features": self.feature_names,
            "shap_values": sv.tolist(),
            "base_value": float(base),
            "prediction_contribution": float(sv.sum()),
        }

    def _detect_model_type(self) -> str:
        """Detect SHAP explainer type from model class name."""
        model = self.model
        # Unwrap calibrated or pipeline models
        if hasattr(model, "estimator"):
            model = model.estimator
        class_name = type(model).__name__.lower()
        if any(k in class_name for k in ["forest", "tree", "boost", "xgb", "lgbm"]):
            return "tree"
        elif any(k in class_name for k in ["logistic", "linear", "ridge", "lasso"]):
            return "linear"
        return "kernel"

    def get_interaction_effects(
        self,
        X: np.ndarray,
        feature_a: str,
        feature_b: str,
        n_samples: int = 500,
    ) -> pd.DataFrame:
        """
        Compute SHAP interaction between two features (approximate).

        Args:
            X: Feature matrix.
            feature_a: First feature name.
            feature_b: Second feature name.
            n_samples: Number of samples to use.

        Returns:
            DataFrame with feature_a values, feature_b values, and SHAP impact.
        """
        if self.shap_values is None:
            self.explain(X, n_samples=n_samples)

        idx_a = self.feature_names.index(feature_a)
        idx_b = self.feature_names.index(feature_b)

        X_sub = self._explained_X if hasattr(self, "_explained_X") else X[:n_samples]
        sv = self.shap_values

        return pd.DataFrame({
            feature_a: X_sub[:, idx_a],
            feature_b: X_sub[:, idx_b],
            "shap_impact": sv[:, idx_a],
        })


class BiasAttributionAnalyzer:
    """
    High-level interface for attributing model bias to specific features.

    Uses SHAP group comparison to identify features that contribute most
    to outcome disparities between demographic groups.
    """

    def __init__(self, shap_explainer: SHAPExplainer) -> None:
        self.explainer = shap_explainer

    def get_bias_drivers(
        self,
        df_meta: pd.DataFrame,
        sensitive_col: str = "race_binary",
        top_k: int = 10,
    ) -> pd.DataFrame:
        """
        Identify top-K features most responsible for prediction disparities.

        Args:
            df_meta: Metadata DataFrame aligned with explained samples.
            sensitive_col: Sensitive attribute column name.
            top_k: Number of top bias-driving features to return.

        Returns:
            DataFrame of top bias drivers with SHAP difference scores.
        """
        comparison = self.explainer.get_group_shap_comparison(
            df_meta, sensitive_col=sensitive_col
        )
        if "difference" not in comparison:
            return comparison.get("global", pd.DataFrame())

        diff = comparison["difference"].reset_index()
        diff = diff.rename(columns={"shap_diff": "bias_contribution"})
        diff["abs_bias_contribution"] = diff["bias_contribution"].abs()
        return diff.nlargest(top_k, "abs_bias_contribution").reset_index(drop=True)

    def generate_bias_narrative(
        self, df_meta: pd.DataFrame, sensitive_col: str = "race_binary", top_k: int = 5
    ) -> str:
        """
        Generate a natural-language summary of bias attribution.

        Returns:
            Human-readable narrative string.
        """
        drivers = self.get_bias_drivers(df_meta, sensitive_col, top_k)
        if drivers.empty:
            return "Bias attribution analysis could not be completed."

        lines = [
            f"\n  BIAS ATTRIBUTION ANALYSIS (Top {top_k} Drivers)",
            f"  {'='*50}",
            f"  Features where the model treats groups differently:\n",
        ]
        for _, row in drivers.iterrows():
            direction = "HIGHER" if row["bias_contribution"] > 0 else "LOWER"
            lines.append(
                f"  • {row['feature']:<30} "
                f"Unprivileged group receives {direction} SHAP weight "
                f"(diff={row['bias_contribution']:+.4f})"
            )
        lines.append(
            "\n  Positive diff → model penalizes unprivileged group more on this feature."
        )
        return "\n".join(lines)
